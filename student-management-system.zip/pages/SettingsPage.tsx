
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import CogIcon from '../components/icons/CogIcon';
import SunIcon from '../components/icons/SunIcon';
import MoonIcon from '../components/icons/MoonIcon';

const SettingsPage: React.FC = () => {
  const { theme, setTheme } = useAppContext();

  const handleThemeChange = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Settings</h1>
        <CogIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Appearance">
        <div className="space-y-4">
          <div>
            <h3 className="text-md font-medium text-slate-700 dark:text-slate-200 mb-2">Theme</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => handleThemeChange('light')}
                className={`px-4 py-2 rounded-md flex items-center space-x-2 text-sm font-medium transition-colors
                  ${theme === 'light' ? 'bg-sky-500 text-white ring-2 ring-sky-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}
              >
                <SunIcon className="w-5 h-5" />
                <span>Light</span>
              </button>
              <button
                onClick={() => handleThemeChange('dark')}
                className={`px-4 py-2 rounded-md flex items-center space-x-2 text-sm font-medium transition-colors
                  ${theme === 'dark' ? 'bg-sky-500 text-white ring-2 ring-sky-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}
              >
                <MoonIcon className="w-5 h-5" />
                <span>Dark</span>
              </button>
            </div>
          </div>
        </div>
      </Card>
      
      <Card title="Language">
        <div>
          <label htmlFor="language" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Select Language
          </label>
          <select 
            id="language" 
            name="language"
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm rounded-md dark:bg-slate-700 dark:text-white"
            defaultValue="en"
          >
            <option value="en">English</option>
            <option value="es" disabled>Español (coming soon)</option>
            <option value="fr" disabled>Français (coming soon)</option>
          </select>
        </div>
      </Card>

      <Card title="Notification Preferences">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Email Notifications</span>
            <label htmlFor="emailNotificationsToggle" className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" id="emailNotificationsToggle" className="sr-only peer" defaultChecked/>
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 dark:peer-focus:ring-sky-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-sky-600"></div>
            </label>
          </div>
           <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Push Notifications (Browser)</span>
             <label htmlFor="pushNotificationsToggle" className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" value="" id="pushNotificationsToggle" className="sr-only peer" />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sky-300 dark:peer-focus:ring-sky-800 rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-500 peer-checked:bg-sky-600"></div>
            </label>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default SettingsPage;
