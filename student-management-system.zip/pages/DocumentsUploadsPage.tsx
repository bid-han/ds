import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { StudentDocument } from '../types';
import { mockStudentDocuments } from '../services/mockData';
import DocumentTextIcon from '../components/icons/DocumentTextIcon';
import UploadIcon from '../components/icons/UploadIcon';
import LoadingSpinner from '../components/LoadingSpinner';

const DocumentsUploadsPage: React.FC = () => {
  const { currentUser } = useAppContext();
  // In a real app, documents would be associated with currentUser.id
  const [documents, setDocuments] = useState<StudentDocument[]>(mockStudentDocuments);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Form state for new upload
  const [documentName, setDocumentName] = useState('');
  const [documentType, setDocumentType] = useState<'Certificate' | 'ID Card' | 'Report' | 'Other'>('Other');
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileToUpload(e.target.files[0]);
      if (!documentName) { // Auto-fill name if empty
        setDocumentName(e.target.files[0].name.replace(/\.[^/.]+$/, "")); // Remove extension
      }
    } else {
      setFileToUpload(null);
    }
  };

  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileToUpload || !documentName) return;
    setIsLoading(true);

    // Simulate API call & file upload
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newDocument: StudentDocument = {
      id: `doc${documents.length + 1 + Date.now()}`,
      name: documentName,
      type: documentType,
      uploadDate: new Date().toISOString().split('T')[0],
      fileUrl: URL.createObjectURL(fileToUpload), // Mock URL
      size: `${(fileToUpload.size / (1024 * 1024)).toFixed(2)}MB` // Calculate size
    };
    setDocuments(prev => [newDocument, ...prev]);

    // Reset form
    setDocumentName('');
    setDocumentType('Other');
    setFileToUpload(null);
    (document.getElementById('fileUploadInput') as HTMLInputElement).value = ''; // Clear file input
    setShowUploadForm(false);
    setIsLoading(false);
    // Show success message ideally
  };
  
  const documentTypeOptions: StudentDocument['type'][] = ['Certificate', 'ID Card', 'Report', 'Other'];


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">My Documents</h1>
        <UploadIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 flex justify-end">
          <button
            onClick={() => setShowUploadForm(!showUploadForm)}
            className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-lg shadow hover:bg-sky-700 transition-colors text-sm"
          >
            {showUploadForm ? 'Cancel Upload' : 'Upload New Document'}
          </button>
        </div>

        {showUploadForm && (
          <form onSubmit={handleUploadDocument} className="p-4 border-t border-slate-200 dark:border-slate-700 space-y-4">
            <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">Upload Document</h3>
            <div>
              <label htmlFor="documentName" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Document Name</label>
              <input type="text" id="documentName" value={documentName} onChange={e => setDocumentName(e.target.value)} required
                     className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="documentType" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Document Type</label>
              <select id="documentType" value={documentType} onChange={e => setDocumentType(e.target.value as StudentDocument['type'])}
                      className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white">
                {documentTypeOptions.map(type => <option key={type} value={type}>{type}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="fileUploadInput" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Select File</label>
              <div className="mt-1 flex items-center space-x-2 p-3 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg">
                <UploadIcon className="w-6 h-6 text-slate-400 dark:text-slate-500" />
                <input type="file" id="fileUploadInput" onChange={handleFileChange} required
                       className="block w-full text-sm text-slate-500 dark:text-slate-400
                                 file:mr-4 file:py-1.5 file:px-3
                                 file:rounded-md file:border-0
                                 file:text-sm file:font-semibold
                                 file:bg-sky-50 file:text-sky-700 dark:file:bg-sky-700/30 dark:file:text-sky-300
                                 hover:file:bg-sky-100 dark:hover:file:bg-sky-600/40"
                />
              </div>
              {fileToUpload && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Selected: {fileToUpload.name} ({(fileToUpload.size / (1024*1024)).toFixed(2)} MB)</p>}
            </div>
            <div className="text-right">
              <button type="submit" disabled={isLoading || !fileToUpload}
                      className="px-6 py-2.5 bg-green-600 hover:bg-green-700 disabled:bg-slate-400 text-white font-semibold rounded-lg shadow hover:shadow-md transition-colors flex items-center justify-center min-w-[120px]">
                {isLoading ? <LoadingSpinner size="h-5 w-5" /> : 'Upload'}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 border-t border-slate-200 dark:border-slate-700">
          <h3 className="p-4 text-lg font-semibold text-slate-700 dark:text-slate-200">Uploaded Documents</h3>
          {documents.length > 0 ? (
            <ul className="divide-y divide-slate-200 dark:divide-slate-700">
              {documents.sort((a,b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()).map(doc => (
                <li key={doc.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                  <div className="flex items-center space-x-3">
                    <DocumentTextIcon className="w-8 h-8 text-sky-500 flex-shrink-0" />
                    <div className="flex-grow">
                      <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer" className="text-md font-semibold text-sky-600 hover:underline dark:text-sky-400">{doc.name}</a>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Type: {doc.type} | Uploaded: {new Date(doc.uploadDate).toLocaleDateString()} | Size: {doc.size}</p>
                    </div>
                    <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer"
                       className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-3 border border-sky-500 rounded-md hover:bg-sky-500/10">
                      View
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500 dark:text-slate-400 text-center py-8">No documents uploaded yet.</p>
          )}
        </div>
      </Card>
    </div>
  );
};

export default DocumentsUploadsPage;
