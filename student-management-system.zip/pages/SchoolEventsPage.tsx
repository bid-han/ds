import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { CalendarEvent } from '../types';
import { mockCalendarEvents } from '../services/mockData';
import { CalendarIcon } from '../components/icons'; // Re-use
import Modal from '../components/ui/Modal';

const SchoolEventsPage: React.FC = () => {
  // Filter only 'event' type from calendar events for this page
  const schoolEvents = mockCalendarEvents.filter(event => event.type === 'event' && event.calendarType === 'academic');
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  const upcomingEvents = schoolEvents.filter(event => new Date(event.date) >= new Date()).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const pastEvents = schoolEvents.filter(event => new Date(event.date) < new Date()).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5); // Show recent 5

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">School Events</h1>
        <CalendarIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Upcoming Events" className="shadow-lg">
        {upcomingEvents.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {upcomingEvents.map(event => (
              <li key={event.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-sky-600 dark:text-sky-400">{event.title}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Date: {new Date(event.date).toLocaleDateString()}</p>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mt-1 truncate">{event.description}</p>
                  </div>
                  <button 
                    onClick={() => setSelectedEvent(event)}
                    className="mt-2 sm:mt-0 text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-3 border border-sky-500 rounded-md hover:bg-sky-500/10"
                  >
                    View Details
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No upcoming school events.</p>
        )}
      </Card>

      <Card title="Recent Past Events" className="shadow-lg">
        {pastEvents.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {pastEvents.map(event => (
              <li key={event.id} className="p-4 opacity-80 hover:opacity-100 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-all">
                <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                  <div>
                    <h3 className="text-md font-semibold text-slate-700 dark:text-slate-300">{event.title}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Date: {new Date(event.date).toLocaleDateString()}</p>
                  </div>
                   <button 
                    onClick={() => setSelectedEvent(event)}
                    className="mt-2 sm:mt-0 text-xs text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-0.5 px-2 border border-sky-500 rounded-md hover:bg-sky-500/10"
                  >
                    Details
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No recent past events.</p>
        )}
      </Card>
      
      <Modal isOpen={!!selectedEvent} onClose={() => setSelectedEvent(null)} title={selectedEvent?.title}>
        {selectedEvent && (
          <div>
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-2"><strong>Date:</strong> {new Date(selectedEvent.date).toLocaleDateString()}</p>
            <p className="text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{selectedEvent.description}</p>
            {/* Add more event-specific details here if available, e.g., location, participants */}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default SchoolEventsPage;
