import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { MediaItem } from '../types';
import { mockMediaItems } from '../services/mockData';
import { PhotographIcon, PlayIcon } from '../components/icons'; // PlayIcon might need creation, PhotographIcon likely exists
import Modal from '../components/ui/Modal';

const MediaGalleryPage: React.FC = () => {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>(mockMediaItems);
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  const [filter, setFilter] = useState<'all' | 'image' | 'video'>('all');

  const filteredMedia = mediaItems.filter(item => filter === 'all' || item.type === filter);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Media Gallery</h1>
        <PhotographIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 border-b dark:border-slate-700 flex space-x-2">
            {(['all', 'image', 'video'] as const).map(type => (
                <button 
                    key={type}
                    onClick={() => setFilter(type)}
                    className={`px-4 py-1.5 text-sm font-medium rounded-md capitalize transition-colors
                        ${filter === type ? 'bg-sky-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}
                >
                    {type}s
                </button>
            ))}
        </div>
        {filteredMedia.length > 0 ? (
          <div className="p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredMedia.map(item => (
              <button 
                key={item.id} 
                onClick={() => setSelectedMedia(item)}
                className="aspect-square bg-slate-100 dark:bg-slate-700 rounded-lg overflow-hidden group relative shadow-md hover:shadow-xl transition-shadow"
              >
                <img src={item.thumbnailUrl || item.url} alt={item.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.type === 'video' ? 
                    <PlayIcon className="w-10 h-10 text-white" /> : 
                    <PhotographIcon className="w-10 h-10 text-white" />
                  }
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/70 to-transparent">
                    <p className="text-xs text-white truncate font-medium">{item.title}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No media items found for this filter.</p>
        )}
      </Card>

      <Modal isOpen={!!selectedMedia} onClose={() => setSelectedMedia(null)} title={selectedMedia?.title} size="xl">
        {selectedMedia && (
          <div className="space-y-3">
            {selectedMedia.type === 'image' ? (
              <img src={selectedMedia.url} alt={selectedMedia.title} className="w-full max-h-[70vh] object-contain rounded-lg" />
            ) : (
              // Basic video placeholder - for real use, an iframe or video player component
              <div className="aspect-video bg-black flex items-center justify-center rounded-lg">
                 <a href={selectedMedia.url} target="_blank" rel="noopener noreferrer" className="text-white text-lg flex items-center space-x-2">
                    <PlayIcon className="w-12 h-12" /> <span>Play Video (External Link)</span>
                 </a>
              </div>
            )}
            {selectedMedia.description && <p className="text-sm text-slate-600 dark:text-slate-300">{selectedMedia.description}</p>}
            {selectedMedia.eventDate && <p className="text-xs text-slate-500 dark:text-slate-400">Event Date: {new Date(selectedMedia.eventDate).toLocaleDateString()}</p>}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MediaGalleryPage;
