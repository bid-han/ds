import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { Appreciation } from '../types';
import { mockAppreciations } from '../services/mockData';
import { SparklesIcon } from '../components/icons'; // SparklesIcon might need creation
import Modal from '../components/ui/Modal';

const AppreciationsPage: React.FC = () => {
  const [appreciations, setAppreciations] = useState<Appreciation[]>(mockAppreciations);
  const [selectedAppreciation, setSelectedAppreciation] = useState<Appreciation | null>(null);
  
  const getCategoryStyle = (category: Appreciation['category']) => {
    switch (category) {
      case 'Academic': return 'border-sky-500 bg-sky-50 dark:bg-sky-500/10';
      case 'Sports': return 'border-green-500 bg-green-50 dark:bg-green-500/10';
      case 'Arts': return 'border-purple-500 bg-purple-50 dark:bg-purple-500/10';
      case 'Conduct': return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-500/10';
      default: return 'border-slate-300 bg-slate-50 dark:bg-slate-700/10';
    }
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Appreciations & Awards</h1>
        <SparklesIcon className="w-8 h-8 text-yellow-400" />
      </div>

      {appreciations.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {appreciations.sort((a,b) => new Date(b.awardedDate).getTime() - new Date(a.awardedDate).getTime()).map(appr => (
            <Card 
              key={appr.id} 
              className={`shadow-lg hover:shadow-xl transition-shadow border-l-4 ${getCategoryStyle(appr.category)}`}
            >
              <div className="p-4">
                <span className={`px-2 py-0.5 text-xs font-semibold rounded-full mb-2 inline-block ${getCategoryStyle(appr.category).replace('border-l-4', '').replace('border-', 'text-').replace('bg-', 'bg-opacity-100')}`}>
                    {appr.category}
                </span>
                <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-1">{appr.title}</h2>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">{appr.description}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Awarded by {appr.awardedBy} on {new Date(appr.awardedDate).toLocaleDateString()}
                </p>
                {appr.certificateUrl && (
                     <button 
                        onClick={() => setSelectedAppreciation(appr)}
                        className="mt-3 text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium"
                      >
                        View Certificate &rarr;
                      </button>
                )}
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="shadow-lg">
            <p className="text-slate-500 dark:text-slate-400 text-center py-12">No appreciations or awards received yet.</p>
        </Card>
      )}

      <Modal isOpen={!!selectedAppreciation} onClose={() => setSelectedAppreciation(null)} title={`Certificate: ${selectedAppreciation?.title}`} size="lg">
        {selectedAppreciation && selectedAppreciation.certificateUrl && (
          <div>
            {/* For actual certificate, you might embed a PDF or show an image */}
            <img src={selectedAppreciation.certificateUrl === '#' ? `https://via.placeholder.com/800x560.png?text=Certificate+for+${selectedAppreciation.title.replace(/\s/g,'+')}` : selectedAppreciation.certificateUrl} 
                 alt={`Certificate for ${selectedAppreciation.title}`}
                 className="w-full h-auto object-contain rounded-md border dark:border-slate-700" />
            <p className="text-center mt-2 text-sm text-slate-500 dark:text-slate-400">This is a mock certificate view.</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AppreciationsPage;
