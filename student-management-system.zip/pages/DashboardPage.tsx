
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { CalendarEvent, NotificationItem } from '../types';
import BellIcon from '../components/icons/BellIcon';
import ClipboardListIcon from '../components/icons/ClipboardListIcon';
import CalendarIcon from '../components/icons/CalendarIcon';
import PresentationChartBarIcon from '../components/icons/PresentationChartBarIcon';

const DashboardPage: React.FC = () => {
  const { currentUser, notifications, calendarEvents } = useAppContext();

  // Mock data aggregation
  const upcomingEvents = calendarEvents.filter(event => new Date(event.date) >= new Date()).slice(0, 3);
  const pendingAssignments = calendarEvents.filter(event => event.type === 'assignment' && new Date(event.date) >= new Date()).slice(0, 3);
  const recentNotifications = notifications.slice(0, 3);
  const attendancePercentage = 92; // Mock data

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">
        Welcome back, {currentUser?.name?.split(' ')[0] || 'Student'}!
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card title="Academic Status" className="bg-sky-500/10 dark:bg-sky-500/20 border border-sky-500/30">
          <div className="text-center">
            <PresentationChartBarIcon className="w-12 h-12 text-sky-500 dark:text-sky-400 mx-auto mb-2" />
            <p className="text-2xl font-semibold text-slate-700 dark:text-slate-200">Good Standing</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Keep up the great work!</p>
          </div>
        </Card>
        <Card title="Attendance" className="bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30">
           <div className="text-center">
            <ClipboardListIcon className="w-12 h-12 text-emerald-500 dark:text-emerald-400 mx-auto mb-2" />
            <p className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">{attendancePercentage}%</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Monthly Average</p>
          </div>
        </Card>
        <Card title="Upcoming Events" className="bg-amber-500/10 dark:bg-amber-500/20 border border-amber-500/30">
          <div className="text-center">
             <CalendarIcon className="w-12 h-12 text-amber-500 dark:text-amber-400 mx-auto mb-2" />
             <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">{upcomingEvents.length}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">View Calendar for details</p>
          </div>
        </Card>
        <Card title="Pending Assignments" className="bg-rose-500/10 dark:bg-rose-500/20 border border-rose-500/30">
           <div className="text-center">
             <BellIcon className="w-12 h-12 text-rose-500 dark:text-rose-400 mx-auto mb-2" />
             <p className="text-3xl font-bold text-rose-600 dark:text-rose-400">{pendingAssignments.length}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Check Assignments tab</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Recent Notifications">
          {recentNotifications.length > 0 ? (
            <ul className="space-y-3">
              {recentNotifications.map(notif => (
                <li key={notif.id} className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-md shadow-sm">
                  <h4 className="font-semibold text-slate-700 dark:text-slate-200">{notif.title}</h4>
                  <p className="text-sm text-slate-500 dark:text-slate-400 truncate">{notif.message}</p>
                  <span className="text-xs text-slate-400 dark:text-slate-500">{new Date(notif.date).toLocaleDateString()}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500 dark:text-slate-400">No recent notifications.</p>
          )}
        </Card>

        <Card title="Quick Links">
          <div className="grid grid-cols-2 gap-3">
            {['assignments', 'timetable', 'report-cards', 'library-access'].map(link => (
              <button 
                key={link}
                onClick={() => useAppContext().setCurrentPage(link)}
                className="p-3 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-sm font-medium transition-colors"
              >
                {link.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;
