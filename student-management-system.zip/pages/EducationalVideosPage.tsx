import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { EducationalVideo } from '../types';
import { mockEducationalVideos } from '../services/mockData';
import { PlayIcon, SearchIcon } from '../components/icons'; // Re-use PlayIcon, SearchIcon
import Modal from '../components/ui/Modal';

const EducationalVideosPage: React.FC = () => {
  const [videos, setVideos] = useState<EducationalVideo[]>(mockEducationalVideos);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<EducationalVideo | null>(null);

  const filteredVideos = videos.filter(video => 
    video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    video.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    video.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Educational Videos</h1>
        <PlayIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 border-b dark:border-slate-700">
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon className="h-5 w-5 text-slate-400 dark:text-slate-500" />
                </div>
                <input 
                    type="text"
                    placeholder="Search videos by title, subject, description..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"
                />
            </div>
        </div>

        {filteredVideos.length > 0 ? (
          <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredVideos.map(video => (
              <button 
                key={video.id} 
                onClick={() => setSelectedVideo(video)}
                className="bg-white dark:bg-slate-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 dark:focus:ring-offset-slate-900"
              >
                <div className="aspect-video bg-slate-200 dark:bg-slate-700 relative group">
                  <img src={video.thumbnailUrl || 'https://via.placeholder.com/300x169.png?text=Video+Thumbnail'} alt={video.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <PlayIcon className="w-12 h-12 text-white" />
                  </div>
                   <span className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1.5 py-0.5 rounded">
                        {video.duration}
                    </span>
                </div>
                <div className="p-3 text-left">
                  <h3 className="text-md font-semibold text-slate-800 dark:text-slate-100 truncate" title={video.title}>{video.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Subject: {video.subject}</p>
                  <p className="text-xs text-slate-400 dark:text-slate-500">By: {video.uploadedBy}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No videos match your search criteria.</p>
        )}
      </Card>

      <Modal isOpen={!!selectedVideo} onClose={() => setSelectedVideo(null)} title={selectedVideo?.title} size="xl">
        {selectedVideo && (
          <div className="space-y-3">
             <div className="aspect-video bg-black rounded-lg overflow-hidden">
                {/* Placeholder for an actual video player or iframe */}
                <iframe 
                    width="100%" 
                    height="100%" 
                    src={`https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1`} // Example YouTube embed (Rickroll!)
                    title={selectedVideo.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                ></iframe>
             </div>
            <p className="text-sm text-slate-600 dark:text-slate-300">{selectedVideo.description}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Subject: {selectedVideo.subject} | Duration: {selectedVideo.duration} | Uploaded by: {selectedVideo.uploadedBy}</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default EducationalVideosPage;
