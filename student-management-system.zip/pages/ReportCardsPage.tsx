import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import { ReportCardSummary, ReportCardSubject } from '../types';
import { mockReportCards } from '../services/mockData';
import AcademicCapIcon from '../components/icons/AcademicCapIcon'; // Create this
import DocumentTextIcon from '../components/icons/DocumentTextIcon'; // Re-use/Create

const ReportCardsPage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [reportCards, setReportCards] = useState<ReportCardSummary[]>(mockReportCards);
  const [selectedReportCard, setSelectedReportCard] = useState<ReportCardSummary | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleViewDetails = (reportCard: ReportCardSummary) => {
    setSelectedReportCard(reportCard);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Report Cards</h1>
        <AcademicCapIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        {reportCards.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {reportCards.sort((a,b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime()).map(reportCard => (
              <li key={reportCard.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <h3 className="text-lg font-semibold text-sky-600 dark:text-sky-400">{reportCard.term}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Issued: {new Date(reportCard.issueDate).toLocaleDateString()}</p>
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                      Overall Grade: <span className="text-green-600 dark:text-green-400">{reportCard.overallGrade} ({reportCard.overallPercentage}%)</span>
                    </p>
                  </div>
                  <div className="mt-3 sm:mt-0 flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
                    <button 
                      onClick={() => handleViewDetails(reportCard)}
                      className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-3 border border-sky-500 rounded-md hover:bg-sky-500/10"
                    >
                      View Details
                    </button>
                    {reportCard.downloadUrl && (
                      <a 
                        href={reportCard.downloadUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-white bg-sky-600 hover:bg-sky-700 py-1.5 px-3 rounded-md shadow flex items-center justify-center"
                      >
                        <DocumentTextIcon className="w-4 h-4 mr-1.5" /> Download PDF
                      </a>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No report cards found.</p>
        )}
      </Card>

      {selectedReportCard && (
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={`Report Card: ${selectedReportCard.term}`} size="lg">
          <div>
            <div className="mb-4">
                <p><strong>Student:</strong> {currentUser?.name}</p>
                <p><strong>Issued Date:</strong> {new Date(selectedReportCard.issueDate).toLocaleDateString()}</p>
                <p><strong>Overall Grade:</strong> <span className="font-semibold text-green-600 dark:text-green-400">{selectedReportCard.overallGrade} ({selectedReportCard.overallPercentage}%)</span></p>
            </div>

            <h4 className="text-md font-semibold text-slate-700 dark:text-slate-200 mb-2">Subject Performance:</h4>
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-md">
              <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                <thead className="bg-slate-50 dark:bg-slate-700/50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Subject</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Marks</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Grade</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Remarks</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                  {selectedReportCard.subjects.map(subject => (
                    <tr key={subject.name}>
                      <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-slate-800 dark:text-slate-100">{subject.name}</td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">{subject.marksObtained}/{subject.totalMarks}</td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm font-semibold text-slate-600 dark:text-slate-300">{subject.grade}</td>
                      <td className="px-4 py-2 text-sm text-slate-500 dark:text-slate-400">{subject.remarks || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {selectedReportCard.teacherComments && (
                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-700/30 rounded-md">
                    <h5 className="font-semibold text-slate-700 dark:text-slate-200">Teacher's Comments:</h5>
                    <p className="text-sm text-slate-600 dark:text-slate-300 italic">"{selectedReportCard.teacherComments}"</p>
                </div>
            )}
             {selectedReportCard.principalComments && (
                <div className="mt-2 p-3 bg-slate-50 dark:bg-slate-700/30 rounded-md">
                    <h5 className="font-semibold text-slate-700 dark:text-slate-200">Principal's Comments:</h5>
                    <p className="text-sm text-slate-600 dark:text-slate-300 italic">"{selectedReportCard.principalComments}"</p>
                </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default ReportCardsPage;
