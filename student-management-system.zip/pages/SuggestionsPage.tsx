import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { Suggestion } from '../types';
import { mockSuggestions } from '../services/mockData';
import { MailIcon, LightBulbIcon } from '../components/icons'; // LightBulbIcon might need creation
import LoadingSpinner from '../components/LoadingSpinner';

const SuggestionsPage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [suggestions, setSuggestions] = useState<Suggestion[]>(
    mockSuggestions.filter(s => s.studentId === currentUser?.id)
  );
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Form state
  const [subject, setSubject] = useState('');
  const [details, setDetails] = useState('');

  const handleSubmitSuggestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setIsLoading(true);

    await new Promise(resolve => setTimeout(resolve, 1000));

    const newSuggestion: Suggestion = {
      id: `sg${suggestions.length + 1 + Date.now()}`,
      studentId: currentUser.id,
      studentName: currentUser.name,
      subject,
      details,
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'Received',
    };
    setSuggestions(prev => [newSuggestion, ...prev]);
    
    setSubject('');
    setDetails('');
    setShowForm(false);
    setIsLoading(false);
  };

  const getStatusColor = (status: Suggestion['status']) => {
    if (status === 'Implemented') return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-700/30';
    if (status === 'Declined') return 'text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-700/30';
    if (status === 'In Review') return 'text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-700/30';
    return 'text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-700/30';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Suggestions & Feedback</h1>
        <LightBulbIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 flex justify-end">
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-lg shadow hover:bg-sky-700 transition-colors text-sm"
          >
            {showForm ? 'Cancel Suggestion' : 'New Suggestion'}
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmitSuggestion} className="p-4 border-t border-slate-200 dark:border-slate-700 space-y-4">
            <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">Submit a Suggestion</h3>
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Subject</label>
              <input type="text" id="subject" value={subject} onChange={e => setSubject(e.target.value)} required 
                     className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="details" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Details</label>
              <textarea id="details" value={details} onChange={e => setDetails(e.target.value)} required rows={4}
                        className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white resize-none"/>
            </div>
            <div className="text-right">
              <button type="submit" disabled={isLoading}
                      className="px-6 py-2.5 bg-green-600 hover:bg-green-700 disabled:bg-slate-400 text-white font-semibold rounded-lg shadow hover:shadow-md transition-colors flex items-center justify-center min-w-[120px]">
                {isLoading ? <LoadingSpinner size="h-5 w-5" /> : 'Submit'}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 border-t border-slate-200 dark:border-slate-700">
          <h3 className="p-4 text-lg font-semibold text-slate-700 dark:text-slate-200">Your Submitted Suggestions</h3>
          {suggestions.length > 0 ? (
            <ul className="divide-y divide-slate-200 dark:divide-slate-700">
              {suggestions.map(sugg => (
                <li key={sugg.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                    <div>
                      <h4 className="font-medium text-slate-700 dark:text-slate-200">{sugg.subject}</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">{sugg.details}</p>
                    </div>
                    <div className="mt-2 sm:mt-0 sm:text-right">
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusColor(sugg.status)}`}>
                            {sugg.status}
                        </span>
                        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Submitted: {new Date(sugg.submittedDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500 dark:text-slate-400 text-center py-8">You haven't submitted any suggestions yet.</p>
          )}
        </div>
      </Card>
    </div>
  );
};

export default SuggestionsPage;
