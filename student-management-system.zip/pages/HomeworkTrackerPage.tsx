import React from 'react';
import Card from '../components/ui/Card';
import { Assignment } from '../types';
import { mockAssignments } from '../services/mockData'; // Re-use assignments
import { CheckCircleIcon, ClipboardListIcon } from '../components/icons';

const HomeworkTrackerPage: React.FC = () => {
  const homeworks: Assignment[] = mockAssignments.filter(a => new Date(a.dueDate) >= new Date() || a.status !== 'Graded').slice(0, 5); // Show upcoming or non-graded
  const completedHomeworks: Assignment[] = mockAssignments.filter(a => a.status === 'Graded').slice(0,5);

  const getProgress = (dueDate: string, assignedDate: string): number => {
    const totalDuration = new Date(dueDate).getTime() - new Date(assignedDate).getTime();
    const elapsedDuration = new Date().getTime() - new Date(assignedDate).getTime();
    if (totalDuration <=0 || elapsedDuration < 0) return 0;
    if (elapsedDuration >= totalDuration) return 100;
    return Math.min(100, (elapsedDuration / totalDuration) * 100);
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Homework Tracker</h1>
        <CheckCircleIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Upcoming / In Progress Homework" className="shadow-lg">
        {homeworks.length > 0 ? (
          <ul className="space-y-4">
            {homeworks.map(hw => (
              <li key={hw.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-md font-semibold text-sky-700 dark:text-sky-300">{hw.title} ({hw.subject})</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400">Due: {new Date(hw.dueDate).toLocaleDateString()}</p>
                    </div>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                        hw.status === 'Pending' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300' : 
                        hw.status === 'Submitted' ? 'bg-blue-100 text-blue-700 dark:bg-blue-700/30 dark:text-blue-300' :
                        'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300'}`}>
                        {hw.status}
                    </span>
                </div>
                {hw.status === 'Pending' && (
                    <div className="mt-2">
                        <div className="w-full bg-slate-200 dark:bg-slate-600 rounded-full h-2.5">
                            <div className={`h-2.5 rounded-full ${getProgress(hw.dueDate, hw.assignedDate) > 75 ? 'bg-red-500' : 'bg-sky-500'}`}
                                 style={{ width: `${getProgress(hw.dueDate, hw.assignedDate)}%` }}>
                            </div>
                        </div>
                        <p className="text-xs text-right text-slate-500 dark:text-slate-400 mt-1">
                            {Math.round(getProgress(hw.dueDate, hw.assignedDate))}% time elapsed
                        </p>
                    </div>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No pending homework. Great job!</p>
        )}
      </Card>

      <Card title="Recently Completed Homework" className="shadow-lg">
        {completedHomeworks.length > 0 ? (
          <ul className="space-y-3">
            {completedHomeworks.map(hw => (
              <li key={hw.id} className="p-3 bg-green-50 dark:bg-green-700/20 rounded-md flex justify-between items-center">
                <div>
                    <h3 className="text-sm font-medium text-green-800 dark:text-green-200">{hw.title} ({hw.subject})</h3>
                    <p className="text-xs text-green-600 dark:text-green-400">Graded: {hw.grade}</p>
                </div>
                <CheckCircleIcon className="w-5 h-5 text-green-500" />
              </li>
            ))}
          </ul>
        ) : (
           <p className="text-slate-500 dark:text-slate-400 text-center py-8">No recently completed homework found.</p>
        )}
      </Card>
    </div>
  );
};

export default HomeworkTrackerPage;
