import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import { Assignment } from '../types';
import { mockAssignments } from '../services/mockData';
import ClipboardListIcon from '../components/icons/ClipboardListIcon'; // Re-use
import UploadIcon from '../components/icons/UploadIcon'; // Create this
import CheckCircleIcon from '../components/icons/CheckCircleIcon'; // Create this

const AssignmentsPage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [assignments, setAssignments] = useState<Assignment[]>(mockAssignments);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const handleViewDetails = (assignment: Assignment) => {
    setSelectedAssignment(assignment);
    setIsModalOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmitAssignment = () => {
    if (selectedAssignment && file) {
      // Mock submission
      console.log(`Submitting ${file.name} for ${selectedAssignment.title}`);
      setAssignments(prev => 
        prev.map(asn => 
          asn.id === selectedAssignment.id ? { ...asn, status: 'Submitted', fileUrl: URL.createObjectURL(file) } : asn
        )
      );
      setIsModalOpen(false);
      setSelectedAssignment(null);
      setFile(null);
      // Show success message ideally
    }
  };

  const getStatusColor = (status: Assignment['status']) => {
    if (status === 'Graded') return 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300';
    if (status === 'Submitted') return 'bg-blue-100 text-blue-700 dark:bg-blue-700/30 dark:text-blue-300';
    return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Assignments</h1>
        <ClipboardListIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        {assignments.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {assignments.sort((a,b) => new Date(b.assignedDate).getTime() - new Date(a.assignedDate).getTime()).map(assignment => (
              <li key={assignment.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <h3 className="text-lg font-semibold text-sky-600 dark:text-sky-400">{assignment.title}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Subject: {assignment.subject}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Due Date: {new Date(assignment.dueDate).toLocaleDateString()}</p>
                  </div>
                  <div className="mt-3 sm:mt-0 flex flex-col sm:items-end space-y-2">
                     <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(assignment.status)}`}>
                        {assignment.status} {assignment.status === 'Graded' && assignment.grade && `(${assignment.grade})`}
                     </span>
                    <button 
                      onClick={() => handleViewDetails(assignment)}
                      className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium"
                    >
                      View Details / Submit
                    </button>
                  </div>
                </div>
                 {assignment.status === 'Submitted' && assignment.fileUrl && (
                    <p className="text-xs text-green-600 dark:text-green-400 mt-2 flex items-center">
                        <CheckCircleIcon className="w-4 h-4 mr-1" />
                        Submitted: <a href={assignment.fileUrl} target="_blank" rel="noopener noreferrer" className="underline ml-1">View Submission</a>
                    </p>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No assignments found.</p>
        )}
      </Card>

      {selectedAssignment && (
        <Modal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setSelectedAssignment(null); setFile(null); }} title={`Assignment: ${selectedAssignment.title}`}>
          <div>
            <h4 className="font-semibold text-slate-700 dark:text-slate-200">Subject: {selectedAssignment.subject}</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400">Assigned: {new Date(selectedAssignment.assignedDate).toLocaleDateString()}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Due: {new Date(selectedAssignment.dueDate).toLocaleDateString()}</p>
            <p className="mt-3 text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{selectedAssignment.description}</p>

            {selectedAssignment.status === 'Graded' && selectedAssignment.grade && (
                 <div className="mt-4 p-3 bg-green-50 dark:bg-green-700/20 rounded-md">
                    <h5 className="font-semibold text-green-700 dark:text-green-300">Grade: {selectedAssignment.grade}</h5>
                </div>
            )}
            
            {selectedAssignment.status === 'Submitted' && selectedAssignment.fileUrl && (
                 <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-700/20 rounded-md">
                    <h5 className="font-semibold text-blue-700 dark:text-blue-300">You have submitted this assignment.</h5>
                     <a href={selectedAssignment.fileUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-sky-600 hover:underline">View your submission</a>
                </div>
            )}

            {selectedAssignment.status === 'Pending' && (
              <div className="mt-6">
                <h5 className="text-md font-semibold text-slate-700 dark:text-slate-200 mb-2">Submit Your Work</h5>
                <div className="flex items-center space-x-2 p-3 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg">
                   <UploadIcon className="w-8 h-8 text-slate-400 dark:text-slate-500" />
                  <input 
                    type="file" 
                    onChange={handleFileChange} 
                    className="block w-full text-sm text-slate-500 dark:text-slate-400
                               file:mr-4 file:py-2 file:px-4
                               file:rounded-full file:border-0
                               file:text-sm file:font-semibold
                               file:bg-sky-50 file:text-sky-700 dark:file:bg-sky-700/30 dark:file:text-sky-300
                               hover:file:bg-sky-100 dark:hover:file:bg-sky-600/40"
                  />
                </div>
                {file && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Selected: {file.name}</p>}
                <button 
                  onClick={handleSubmitAssignment}
                  disabled={!file}
                  className="mt-4 w-full bg-sky-600 hover:bg-sky-700 disabled:bg-slate-400 text-white font-semibold py-2 px-4 rounded-lg shadow hover:shadow-md transition-colors"
                >
                  Submit Assignment
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default AssignmentsPage;
