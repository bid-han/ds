import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import CreditCardIcon from '../components/icons/CreditCardIcon'; // Assuming you have this icon
import UserIcon from '../components/icons/UserIcon';
import { mockStudentAccount } from '../services/mockData'; // Import mock data

const StudentAccountPage: React.FC = () => {
  const { currentUser } = useAppContext();
  const accountDetails = mockStudentAccount; // Use mock data

  if (!currentUser || !accountDetails) {
    return <p>Loading account details...</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Student Account</h1>
        <CreditCardIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Account Holder Information" className="shadow-lg">
        <div className="flex items-center space-x-4 p-2">
          {accountDetails.profilePictureUrl ? (
            <img src={accountDetails.profilePictureUrl} alt="Profile" className="w-16 h-16 rounded-full object-cover" />
          ) : (
            <div className="w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center">
              <UserIcon className="w-10 h-10 text-slate-500 dark:text-slate-400" />
            </div>
          )}
          <div>
            <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">{accountDetails.name}</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">Class: {accountDetails.class} - {accountDetails.section}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Roll No: {accountDetails.rollNumber}</p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card title="Total Fees" titleClassName="bg-blue-500/10 text-blue-700 dark:text-blue-300" bodyClassName="text-center">
            <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">${accountDetails.totalFees.toLocaleString()}</p>
        </Card>
        <Card title="Paid Fees" titleClassName="bg-green-500/10 text-green-700 dark:text-green-300" bodyClassName="text-center">
            <p className="text-4xl font-bold text-green-600 dark:text-green-400">${accountDetails.paidFees.toLocaleString()}</p>
        </Card>
        <Card title="Balance Due" titleClassName={`${accountDetails.balance > 0 ? 'bg-red-500/10 text-red-700 dark:text-red-300' : 'bg-gray-500/10 text-gray-700 dark:text-gray-300'}`} bodyClassName="text-center">
            <p className={`text-4xl font-bold ${accountDetails.balance > 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'}`}>
                ${accountDetails.balance.toLocaleString()}
            </p>
            {accountDetails.balance > 0 && <p className="text-xs text-red-500 dark:text-red-400 mt-1">Payment is overdue.</p>}
        </Card>
      </div>

      <Card title="Payment History" className="shadow-lg">
        {accountDetails.paymentHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
              <thead className="bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Method</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Transaction ID</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                {accountDetails.paymentHistory.map((payment) => (
                  <tr key={payment.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 dark:text-slate-300">{new Date(payment.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700 dark:text-slate-300">${payment.amount.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{payment.method}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-400">{payment.transactionId}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-4">No payment history available.</p>
        )}
        {accountDetails.balance > 0 && (
            <div className="p-4 border-t border-slate-200 dark:border-slate-700 text-right">
                <button className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-lg shadow hover:bg-sky-700 transition-colors text-sm">
                    Pay Balance Due
                </button>
            </div>
        )}
      </Card>
    </div>
  );
};

export default StudentAccountPage;
