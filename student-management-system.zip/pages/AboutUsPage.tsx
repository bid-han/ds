
import React from 'react';
import Card from '../components/ui/Card';
import InformationCircleIcon from '../components/icons/InformationCircleIcon';

const AboutUsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">About Our School</h1>
        <InformationCircleIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Our Mission">
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          Our mission is to foster a challenging and supportive learning environment where students are empowered to reach their full academic and personal potential. We strive to cultivate critical thinking, creativity, and a lifelong love for learning, preparing our students to become responsible global citizens and leaders of tomorrow.
        </p>
      </Card>

      <Card title="Our Vision">
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          To be a premier educational institution recognized for excellence in teaching, innovation in learning, and a commitment to holistic student development. We envision a community where diversity is celebrated, collaboration is encouraged, and every student is inspired to achieve their dreams.
        </p>
      </Card>
      
      <Card title="Our History">
        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
          Founded in 1985, [School Name] has a rich history of academic achievement and community engagement. From humble beginnings with just a few classrooms, we have grown into a vibrant campus serving students from diverse backgrounds. Over the decades, we have remained dedicated to our core values of integrity, respect, and excellence, adapting to the evolving needs of education while preserving our cherished traditions.
        </p>
      </Card>

      <Card title="Contact Us">
        <address className="not-italic text-slate-600 dark:text-slate-300 leading-relaxed">
          <p><strong>[School Name]</strong></p>
          <p>123 Education Lane, Knowledge City, ST 54321</p>
          <p><strong>Phone:</strong> (123) 456-7890</p>
          <p><strong>Email:</strong> <a href="mailto:info@schoolname.edu" className="text-sky-600 hover:underline dark:text-sky-400">info@schoolname.edu</a></p>
        </address>
      </Card>
    </div>
  );
};

export default AboutUsPage;
