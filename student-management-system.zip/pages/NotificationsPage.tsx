
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { NotificationItem } from '../types';
import Card from '../components/ui/Card';
import BellIcon from '../components/icons/BellIcon';

const NotificationCard: React.FC<{ notification: NotificationItem, onMarkAsRead: (id: string) => void }> = ({ notification, onMarkAsRead }) => {
  return (
    <div className={`p-4 rounded-lg shadow transition-all ${notification.read ? 'bg-slate-100 dark:bg-slate-700/50 opacity-70' : 'bg-white dark:bg-slate-700'}`}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-semibold text-slate-800 dark:text-slate-100">{notification.title}</h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">{notification.message}</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-2">{new Date(notification.date).toLocaleString()}</p>
        </div>
        {!notification.read && (
          <button 
            onClick={() => onMarkAsRead(notification.id)}
            className="ml-4 text-xs text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-2 rounded border border-sky-500 hover:bg-sky-500/10"
            aria-label="Mark as read"
          >
            Mark Read
          </button>
        )}
      </div>
      {notification.link && (
        <a href={notification.link} target="_blank" rel="noopener noreferrer" className="text-sm text-sky-600 hover:underline dark:text-sky-400 mt-2 inline-block">
          View Details
        </a>
      )}
    </div>
  );
};

const NotificationsPage: React.FC = () => {
  const { notifications, markNotificationAsRead } = useAppContext();
  const [activeTab, setActiveTab] = useState<'personal' | 'general'>('personal');

  const filteredNotifications = notifications.filter(n => n.type === activeTab);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Notifications</h1>
        <BellIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card>
        <div className="border-b border-slate-200 dark:border-slate-700">
          <nav className="-mb-px flex space-x-6" aria-label="Tabs">
            {(['personal', 'general'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm capitalize
                  ${activeTab === tab
                    ? 'border-sky-500 text-sky-600 dark:text-sky-400'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:border-slate-600'
                  }`}
              >
                {tab} Notifications
              </button>
            ))}
          </nav>
        </div>

        {filteredNotifications.length > 0 ? (
          <div className="mt-6 space-y-4">
            {filteredNotifications.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(notification => (
              <NotificationCard key={notification.id} notification={notification} onMarkAsRead={markNotificationAsRead} />
            ))}
          </div>
        ) : (
          <p className="mt-6 text-center text-slate-500 dark:text-slate-400 py-8">
            No {activeTab} notifications at the moment.
          </p>
        )}
      </Card>
    </div>
  );
};

export default NotificationsPage;
