
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import CogIcon from '../components/icons/CogIcon'; // Generic icon

const PlaceholderPage: React.FC = () => {
  const { currentPage } = useAppContext();
  
  // Capitalize and format the page name for display
  const pageTitle = currentPage
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">{pageTitle}</h1>
        <CogIcon className="w-8 h-8 text-sky-500 animate-spin-slow" />
      </div>

      <Card>
        <div className="text-center py-12">
          <CogIcon className="w-16 h-16 text-slate-400 dark:text-slate-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Coming Soon!</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-2">
            The "{pageTitle}" section is currently under development.
          </p>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            Please check back later for updates.
          </p>
          <button
            onClick={() => useAppContext().setCurrentPage('dashboard')}
            className="mt-6 px-6 py-2 bg-sky-600 text-white font-semibold rounded-lg shadow hover:bg-sky-700 transition-colors"
          >
            Go to Dashboard
          </button>
        </div>
      </Card>
      {/* Fix: Removed invalid `jsx` and `global` props from the style tag. */}
      <style>{`
        @keyframes spin-slow {
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 5s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default PlaceholderPage;