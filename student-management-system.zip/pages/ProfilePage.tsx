
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import UserIcon from '../components/icons/UserIcon';
import LoadingSpinner from '../components/LoadingSpinner';

const ProfilePage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Mock form state - in a real app, this would be part of currentUser or separate state
  const [formData, setFormData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: '123-456-7890', // mock
    address: '123 Main St, Anytown, USA', // mock
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasswordData({ ...passwordData, [e.target.name]: e.target.value });
  };

  const handleEditToggle = () => setIsEditing(!isEditing);

  const handleSaveChanges = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Saving data:", formData); // In real app, update context/backend
    setIsLoading(false);
    setIsEditing(false);
    // Potentially show a success message
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Changing password with data:", passwordData);
    setIsLoading(false);
    setPasswordData({currentPassword: '', newPassword: '', confirmPassword: ''});
    // Potentially show a success message or error
  };


  if (!currentUser) {
    return <p>Loading profile...</p>; 
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">My Profile</h1>
        <UserIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card>
        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 p-4">
          {currentUser.profilePictureUrl ? (
            <img src={currentUser.profilePictureUrl} alt="Profile" className="w-24 h-24 rounded-full object-cover shadow-md" />
          ) : (
            <div className="w-24 h-24 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center shadow-md">
              <UserIcon className="w-12 h-12 text-slate-500 dark:text-slate-400" />
            </div>
          )}
          <div>
            <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-100">{currentUser.name}</h2>
            <p className="text-slate-500 dark:text-slate-400">{currentUser.email}</p>
            <p className="text-sm text-slate-400 dark:text-slate-500">Class: {currentUser.class} - Section {currentUser.section}</p>
            <label htmlFor="profile-picture-upload" className="mt-2 inline-block text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 cursor-pointer">
              {isEditing ? 'Upload new picture' : 'Change Picture'}
              <input type="file" id="profile-picture-upload" className="hidden" disabled={!isEditing} />
            </label>
          </div>
        </div>
      </Card>

      <Card title="Personal Details">
        <form onSubmit={(e) => { e.preventDefault(); handleSaveChanges(); }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Full Name</label>
              <input type="text" name="name" id="name" value={formData.name} onChange={handleInputChange} disabled={!isEditing} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm disabled:bg-slate-50 dark:disabled:bg-slate-700 dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email Address</label>
              <input type="email" name="email" id="email" value={formData.email} onChange={handleInputChange} disabled={!isEditing} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm disabled:bg-slate-50 dark:disabled:bg-slate-700 dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Phone Number</label>
              <input type="tel" name="phone" id="phone" value={formData.phone} onChange={handleInputChange} disabled={!isEditing} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm disabled:bg-slate-50 dark:disabled:bg-slate-700 dark:bg-slate-700/50 dark:text-white"/>
            </div>
             <div>
              <label htmlFor="address" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Address</label>
              <textarea name="address" id="address" rows={3} value={formData.address} onChange={handleInputChange} disabled={!isEditing} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm disabled:bg-slate-50 dark:disabled:bg-slate-700 dark:bg-slate-700/50 dark:text-white resize-none"/>
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={handleEditToggle}
              className="px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 dark:focus:ring-offset-slate-800"
            >
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </button>
            {isEditing && (
              <button
                type="submit"
                disabled={isLoading}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 disabled:bg-slate-400 dark:focus:ring-offset-slate-800 flex items-center"
              >
                {isLoading && <LoadingSpinner size="h-4 w-4 mr-2" />}
                Save Changes
              </button>
            )}
          </div>
        </form>
      </Card>

      <Card title="Change Password">
        <form onSubmit={handleChangePassword} className="space-y-4">
           <div>
              <label htmlFor="currentPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Current Password</label>
              <input type="password" name="currentPassword" id="currentPassword" value={passwordData.currentPassword} onChange={handlePasswordChange} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="newPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-300">New Password</label>
              <input type="password" name="newPassword" id="newPassword" value={passwordData.newPassword} onChange={handlePasswordChange} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
            </div>
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Confirm New Password</label>
              <input type="password" name="confirmPassword" id="confirmPassword" value={passwordData.confirmPassword} onChange={handlePasswordChange} className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
            </div>
             <div className="flex justify-end">
                 <button
                    type="submit"
                    disabled={isLoading || !passwordData.currentPassword || !passwordData.newPassword || passwordData.newPassword !== passwordData.confirmPassword}
                    className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 disabled:bg-slate-400 dark:focus:ring-offset-slate-800 flex items-center"
                  >
                    {isLoading && <LoadingSpinner size="h-4 w-4 mr-2" />}
                    Change Password
                  </button>
            </div>
        </form>
      </Card>
    </div>
  );
};

export default ProfilePage;
