import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { AttendanceRecord } from '../types';
import { mockAttendance } from '../services/mockData';
import PresentationChartBarIcon from '../components/icons/PresentationChartBarIcon'; // Re-use

const AttendancePage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(mockAttendance);

  // Calculate overall attendance (simple average for mock)
  const overallPercentage = attendanceRecords.length > 0 
    ? attendanceRecords.reduce((sum, record) => sum + record.percentage, 0) / attendanceRecords.length
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Attendance Records</h1>
        <PresentationChartBarIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Overall Attendance Summary" className="shadow-lg">
        <div className="p-4 text-center">
          <p className="text-sm text-slate-500 dark:text-slate-400">Your average attendance is</p>
          <p className={`text-5xl font-bold mt-1 ${overallPercentage >= 75 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
            {overallPercentage.toFixed(1)}%
          </p>
          {overallPercentage < 75 && <p className="text-xs text-red-500 dark:text-red-400 mt-1">Please improve your attendance.</p>}
        </div>
      </Card>

      <Card title="Monthly Breakdown" className="shadow-lg">
        {attendanceRecords.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {attendanceRecords.sort((a,b) => new Date(b.month).getTime() - new Date(a.month).getTime()).map(record => ( // Basic sort, might need better month parsing
              <li key={record.month} className="p-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-2">
                  <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">{record.month}</h3>
                  <div className="flex space-x-4 text-sm text-slate-500 dark:text-slate-400 mt-1 sm:mt-0">
                    <span>Total: {record.totalDays}</span>
                    <span className="text-green-600 dark:text-green-400">Present: {record.presentDays}</span>
                    <span className="text-red-600 dark:text-red-400">Absent: {record.absentDays}</span>
                  </div>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-4">
                  <div 
                    className={`h-4 rounded-full ${record.percentage >= 75 ? 'bg-green-500' : 'bg-red-500'} transition-all duration-500`}
                    style={{ width: `${record.percentage}%` }}
                    title={`${record.percentage.toFixed(1)}%`}
                  ></div>
                </div>
                <p className="text-right text-xs mt-1 font-medium text-slate-600 dark:text-slate-300">{record.percentage.toFixed(1)}%</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No attendance records found.</p>
        )}
      </Card>
      
       <Card title="View Daily Log (Example for October 2024)" bodyClassName="p-0">
         {attendanceRecords.find(r => r.month === 'October 2024')?.dailyRecords ? (
            <div className="max-h-60 overflow-y-auto">
                <table className="min-w-full text-sm">
                    <thead className="sticky top-0 bg-slate-100 dark:bg-slate-700/80 backdrop-blur-sm">
                        <tr>
                            <th className="p-2 text-left font-medium text-slate-600 dark:text-slate-300">Date</th>
                            <th className="p-2 text-left font-medium text-slate-600 dark:text-slate-300">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                    {attendanceRecords.find(r => r.month === 'October 2024')?.dailyRecords?.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(day => (
                        <tr key={day.date} className="hover:bg-slate-50 dark:hover:bg-slate-700/30">
                            <td className="p-2 text-slate-700 dark:text-slate-300">{new Date(day.date).toLocaleDateString()}</td>
                            <td className={`p-2 font-medium ${
                                day.status === 'Present' ? 'text-green-600 dark:text-green-400' : 
                                day.status === 'Absent' ? 'text-red-600 dark:text-red-400' : 
                                'text-yellow-600 dark:text-yellow-400'}`}>
                                {day.status}
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
         ) : (
            <p className="text-slate-500 dark:text-slate-400 text-center py-4">No daily log for October 2024.</p>
         )}
       </Card>
    </div>
  );
};

export default AttendancePage;
