import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { LibraryBook } from '../types';
import { mockLibraryBooks } from '../services/mockData';
import { BookOpenIcon, SearchIcon } from '../components/icons'; // SearchIcon might need creation
import Modal from '../components/ui/Modal';

const LibraryAccessPage: React.FC = () => {
  const [books, setBooks] = useState<LibraryBook[]>(mockLibraryBooks);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBook, setSelectedBook] = useState<LibraryBook | null>(null);

  const filteredBooks = books.filter(book => 
    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
    book.isbn.includes(searchTerm) ||
    book.genre.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Library Access</h1>
        <BookOpenIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 border-b dark:border-slate-700">
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon className="h-5 w-5 text-slate-400 dark:text-slate-500" /> 
                </div>
                <input 
                    type="text"
                    placeholder="Search by title, author, ISBN, genre..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"
                />
            </div>
        </div>

        {filteredBooks.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {filteredBooks.map(book => (
              <li key={book.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex flex-col sm:flex-row items-start sm:items-center space-x-0 sm:space-x-4">
                  <img 
                    src={book.coverImageUrl || 'https://via.placeholder.com/80x120.png?text=No+Cover'} 
                    alt={book.title} 
                    className="w-20 h-30 object-cover rounded flex-shrink-0 mb-3 sm:mb-0"
                  />
                  <div className="flex-grow">
                    <h3 className="text-lg font-semibold text-sky-600 dark:text-sky-400">{book.title}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">by {book.author}</p>
                    <p className="text-xs text-slate-400 dark:text-slate-500">Genre: {book.genre} | ISBN: {book.isbn}</p>
                    <p className={`text-xs font-medium mt-1 ${book.availableCopies > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      {book.availableCopies > 0 ? `${book.availableCopies} of ${book.totalCopies} available` : 'Currently Unavailable'}
                    </p>
                  </div>
                  <button 
                    onClick={() => setSelectedBook(book)}
                    className="mt-2 sm:mt-0 text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-3 border border-sky-500 rounded-md hover:bg-sky-500/10"
                  >
                    Details
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No books match your search criteria.</p>
        )}
      </Card>

       <Modal isOpen={!!selectedBook} onClose={() => setSelectedBook(null)} title={selectedBook?.title}>
        {selectedBook && (
          <div className="flex flex-col sm:flex-row space-x-0 sm:space-x-4">
            <img 
                src={selectedBook.coverImageUrl || 'https://via.placeholder.com/100x150.png?text=No+Cover'} 
                alt={selectedBook.title} 
                className="w-24 h-36 sm:w-32 sm:h-48 object-cover rounded flex-shrink-0 mb-3 sm:mb-0 mx-auto sm:mx-0"
            />
            <div className="flex-grow">
                <p className="text-sm text-slate-600 dark:text-slate-300"><strong>Author:</strong> {selectedBook.author}</p>
                <p className="text-sm text-slate-600 dark:text-slate-300"><strong>Genre:</strong> {selectedBook.genre}</p>
                <p className="text-sm text-slate-600 dark:text-slate-300"><strong>ISBN:</strong> {selectedBook.isbn}</p>
                <p className={`text-sm font-medium mt-2 ${selectedBook.availableCopies > 0 ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                    Status: {selectedBook.availableCopies > 0 ? `${selectedBook.availableCopies} available / ${selectedBook.totalCopies} total` : 'Currently Unavailable'}
                </p>
                {/* Add more details like summary if available */}
                {selectedBook.availableCopies > 0 && (
                    <button className="mt-4 w-full bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2 px-4 rounded-lg shadow">
                        Request to Borrow
                    </button>
                )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default LibraryAccessPage;
