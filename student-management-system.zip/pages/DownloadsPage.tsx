import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { DownloadableFile } from '../types';
import { mockDownloadableFiles } from '../services/mockData';
import { DownloadIcon, DocumentTextIcon } from '../components/icons'; // DownloadIcon might need creation

const DownloadsPage: React.FC = () => {
  const [files, setFiles] = useState<DownloadableFile[]>(mockDownloadableFiles);
  const [filterCategory, setFilterCategory] = useState<'All' | 'Form' | 'Syllabus' | 'Document'>('All');

  const filteredFiles = files.filter(file => 
    filterCategory === 'All' || file.category === filterCategory
  );
  
  const getCategoryColor = (category: DownloadableFile['category']) => {
    if (category === 'Form') return 'bg-blue-100 text-blue-700 dark:bg-blue-700/30 dark:text-blue-300';
    if (category === 'Syllabus') return 'bg-purple-100 text-purple-700 dark:bg-purple-700/30 dark:text-purple-300';
    if (category === 'Document') return 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-300';
    return 'bg-slate-100 text-slate-700 dark:bg-slate-600/30 dark:text-slate-300';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Downloads</h1>
        <DownloadIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 border-b dark:border-slate-700 flex flex-wrap gap-2">
            {(['All', 'Form', 'Syllabus', 'Document'] as const).map(category => (
                <button 
                    key={category}
                    onClick={() => setFilterCategory(category)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md capitalize transition-colors
                        ${filterCategory === category ? 'bg-sky-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}
                >
                    {category}s
                </button>
            ))}
        </div>
        {filteredFiles.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {filteredFiles.sort((a,b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()).map(file => (
              <li key={file.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex items-center space-x-3">
                    <DocumentTextIcon className="w-7 h-7 text-slate-500 dark:text-slate-400 flex-shrink-0" />
                    <div className="flex-grow">
                        <h3 className="text-md font-semibold text-sky-600 dark:text-sky-400">{file.name}</h3>
                        <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            <span className={`px-1.5 py-0.5 rounded text-xxs font-medium ${getCategoryColor(file.category)}`}>{file.category}</span>
                            <span>|</span>
                            <span>Size: {file.size}</span>
                            <span>|</span>
                            <span>Uploaded: {new Date(file.uploadDate).toLocaleDateString()}</span>
                        </div>
                    </div>
                    <a 
                        href={file.url} 
                        download 
                        className="text-sm text-white bg-sky-600 hover:bg-sky-700 py-1.5 px-3 rounded-md shadow flex items-center"
                    >
                        <DownloadIcon className="w-4 h-4 mr-1.5" /> Download
                    </a>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No files available for this category.</p>
        )}
      </Card>
    </div>
  );
};

export default DownloadsPage;
