import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { ReadingMaterial } from '../types';
import { mockReadingMaterials } from '../services/mockData';
import { BookOpenIcon, DocumentTextIcon, LinkIcon } from '../components/icons'; // LinkIcon might need to be created

const ReadingMaterialsPage: React.FC = () => {
  const [materials, setMaterials] = useState<ReadingMaterial[]>(mockReadingMaterials);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'PDF' | 'Notes' | 'Link'>('All');

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          material.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'All' || material.type === filterType;
    return matchesSearch && matchesType;
  });

  const getTypeIcon = (type: ReadingMaterial['type']) => {
    if (type === 'PDF') return <DocumentTextIcon className="w-5 h-5 text-red-500" />;
    if (type === 'Notes') return <BookOpenIcon className="w-5 h-5 text-yellow-500" />;
    if (type === 'Link') return <LinkIcon className="w-5 h-5 text-blue-500" />; // Create LinkIcon if needed
    return <BookOpenIcon className="w-5 h-5 text-slate-500" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Reading Materials</h1>
        <BookOpenIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between border-b dark:border-slate-700">
            <input 
                type="text"
                placeholder="Search materials..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-1/2 px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"
            />
            <div className="flex space-x-2">
                {(['All', 'PDF', 'Notes', 'Link'] as const).map(type => (
                    <button
                        key={type}
                        onClick={() => setFilterType(type)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors
                            ${filterType === type ? 'bg-sky-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600'}`}
                    >
                        {type}
                    </button>
                ))}
            </div>
        </div>

        {filteredMaterials.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {filteredMaterials.sort((a,b) => new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime()).map(material => (
              <li key={material.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0">{getTypeIcon(material.type)}</div>
                  <div className="flex-grow">
                    <a href={material.url} target="_blank" rel="noopener noreferrer" className="text-md font-semibold text-sky-600 hover:underline dark:text-sky-400">
                        {material.title}
                    </a>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Subject: {material.subject}</p>
                    <p className="text-xs text-slate-400 dark:text-slate-500">Type: {material.type} | Added: {new Date(material.addedDate).toLocaleDateString()}</p>
                  </div>
                  <a href={material.url} target="_blank" rel="noopener noreferrer"
                       className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium py-1 px-3 border border-sky-500 rounded-md hover:bg-sky-500/10">
                      View
                  </a>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No reading materials match your criteria.</p>
        )}
      </Card>
    </div>
  );
};

export default ReadingMaterialsPage;
