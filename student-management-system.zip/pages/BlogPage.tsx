import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { BlogPost } from '../types';
import { mockBlogPosts } from '../services/mockData';
import { RssIcon } from '../components/icons'; // RssIcon might need creation
import Modal from '../components/ui/Modal';

const BlogPage: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>(mockBlogPosts);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">School Blog & News</h1>
        <RssIcon className="w-8 h-8 text-sky-500" />
      </div>

      {posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.sort((a,b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()).map(post => (
            <Card key={post.id} className="shadow-lg hover:shadow-xl transition-shadow flex flex-col">
              {post.imageUrl && (
                <img src={post.imageUrl} alt={post.title} className="w-full h-40 object-cover" />
              )}
              <div className="p-4 flex-grow">
                <h2 className="text-xl font-semibold text-sky-700 dark:text-sky-300 mb-1">{post.title}</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                  By {post.author} on {new Date(post.publishDate).toLocaleDateString()}
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-3 flex-grow">{post.excerpt}</p>
              </div>
              <div className="p-4 border-t dark:border-slate-700">
                 <button 
                    onClick={() => setSelectedPost(post)}
                    className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium"
                  >
                    Read More &rarr;
                  </button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="shadow-lg">
            <p className="text-slate-500 dark:text-slate-400 text-center py-12">No blog posts available at the moment.</p>
        </Card>
      )}

      <Modal isOpen={!!selectedPost} onClose={() => setSelectedPost(null)} title={selectedPost?.title} size="xl">
        {selectedPost && (
          <article className="prose dark:prose-invert max-w-none">
            {selectedPost.imageUrl && (
                 <img src={selectedPost.imageUrl} alt={selectedPost.title} className="w-full max-h-80 object-cover rounded-lg mb-4" />
            )}
            <p className="text-sm text-slate-500 dark:text-slate-400">
              By {selectedPost.author} on {new Date(selectedPost.publishDate).toLocaleDateString()}
            </p>
            {/* For HTML content, use dangerouslySetInnerHTML, or use a Markdown parser */}
            <div dangerouslySetInnerHTML={{ __html: selectedPost.content.replace(/\n/g, '<br />') }} /> 
            {selectedPost.tags && selectedPost.tags.length > 0 && (
                <div className="mt-6">
                    <h4 className="text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">Tags:</h4>
                    <div className="flex flex-wrap gap-2 mt-1">
                        {selectedPost.tags.map(tag => (
                            <span key={tag} className="px-2 py-0.5 bg-sky-100 dark:bg-sky-700/50 text-sky-700 dark:text-sky-300 text-xs rounded-full">{tag}</span>
                        ))}
                    </div>
                </div>
            )}
          </article>
        )}
      </Modal>
    </div>
  );
};

export default BlogPage;
