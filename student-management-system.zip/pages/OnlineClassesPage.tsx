import React from 'react';
import Card from '../components/ui/Card';
import { BookOpenIcon, CalendarIcon, VideoCameraIcon } from '../components/icons'; // Assuming VideoCameraIcon exists or create it

interface OnlineClass {
  id: string;
  subject: string;
  topic: string;
  teacher: string;
  dateTime: string; // e.g., "2024-11-15T10:00:00Z"
  meetingLink: string;
  duration: string; // e.g., "45 minutes"
  materialsLink?: string;
}

const mockOnlineClasses: OnlineClass[] = [
  { id: 'oc1', subject: 'Mathematics', topic: 'Advanced Algebra', teacher: 'Ms. Davison', dateTime: '2024-11-15T10:00:00Z', meetingLink: '#', duration: '50 minutes', materialsLink: '#' },
  { id: 'oc2', subject: 'Science', topic: 'Newton\'s Laws of Motion', teacher: 'Mr. Lee', dateTime: '2024-11-16T11:00:00Z', meetingLink: '#', duration: '50 minutes' },
  { id: 'oc3', subject: 'English Literature', topic: 'Shakespearean Sonnets', teacher: 'Mrs. Peters', dateTime: '2024-11-17T09:00:00Z', meetingLink: '#', duration: '50 minutes', materialsLink: '#' },
];


const OnlineClassesPage: React.FC = () => {
  const upcomingClasses = mockOnlineClasses.filter(cls => new Date(cls.dateTime) > new Date());
  const pastClasses = mockOnlineClasses.filter(cls => new Date(cls.dateTime) <= new Date()).slice(0,5); // Show recent 5

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Online Classes</h1>
        <VideoCameraIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card title="Upcoming Classes" className="shadow-lg">
        {upcomingClasses.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {upcomingClasses.sort((a,b) => new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime()).map(cls => (
              <li key={cls.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <h3 className="text-lg font-semibold text-sky-600 dark:text-sky-400">{cls.subject} - {cls.topic}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Teacher: {cls.teacher}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400 flex items-center">
                      <CalendarIcon className="w-4 h-4 mr-1.5 text-slate-400" />
                      {new Date(cls.dateTime).toLocaleString()} ({cls.duration})
                    </p>
                  </div>
                  <div className="mt-3 sm:mt-0 flex flex-col sm:items-end space-y-2">
                    <a href={cls.meetingLink} target="_blank" rel="noopener noreferrer"
                       className="text-sm text-white bg-green-600 hover:bg-green-700 py-1.5 px-4 rounded-md shadow flex items-center justify-center">
                       <VideoCameraIcon className="w-4 h-4 mr-1.5" /> Join Class
                    </a>
                    {cls.materialsLink && (
                       <a href={cls.materialsLink} target="_blank" rel="noopener noreferrer"
                          className="text-sm text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium flex items-center">
                          <BookOpenIcon className="w-4 h-4 mr-1.5" /> View Materials
                       </a>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No upcoming online classes scheduled.</p>
        )}
      </Card>
      
      <Card title="Recent Past Classes" className="shadow-lg">
        {pastClasses.length > 0 ? (
          <ul className="divide-y divide-slate-200 dark:divide-slate-700">
            {pastClasses.sort((a,b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime()).map(cls => (
              <li key={cls.id} className="p-4 opacity-70 hover:opacity-100 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-all">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <h3 className="text-md font-semibold text-slate-700 dark:text-slate-300">{cls.subject} - {cls.topic}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Teacher: {cls.teacher} | Date: {new Date(cls.dateTime).toLocaleDateString()}</p>
                  </div>
                   {cls.materialsLink && (
                       <a href={cls.materialsLink} target="_blank" rel="noopener noreferrer"
                          className="mt-2 sm:mt-0 text-xs text-sky-600 hover:text-sky-500 dark:text-sky-400 dark:hover:text-sky-300 font-medium flex items-center">
                          <BookOpenIcon className="w-3 h-3 mr-1" /> View Recording/Materials
                       </a>
                    )}
                </div>
              </li>
            ))}
          </ul>
        ) : (
           <p className="text-slate-500 dark:text-slate-400 text-center py-8">No recent past classes found.</p>
        )}
      </Card>
    </div>
  );
};

export default OnlineClassesPage;
