import React, { useState } from 'react';
import Card from '../components/ui/Card';
import { CoursePlanSubject, CoursePlanItem } from '../types';
import { mockCoursePlans } from '../services/mockData';
import { ListBulletIcon, BookOpenIcon, LinkIcon } from '../components/icons'; // ListBulletIcon, LinkIcon might need creation

const CoursePlanItemDisplay: React.FC<{ item: CoursePlanItem }> = ({ item }) => (
  <div className="py-3">
    <h4 className="text-md font-semibold text-slate-700 dark:text-slate-200">{item.unit}: {item.topic}</h4>
    <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Estimated Duration: {item.durationEstimate}</p>
    <strong className="block text-xs font-medium text-slate-600 dark:text-slate-300 mt-1.5">Learning Objectives:</strong>
    <ul className="list-disc list-inside pl-1 space-y-0.5 text-sm text-slate-600 dark:text-slate-300">
      {item.learningObjectives.map((obj, i) => <li key={i} className="text-xs">{obj}</li>)}
    </ul>
    {item.resources && item.resources.length > 0 && (
      <>
        <strong className="block text-xs font-medium text-slate-600 dark:text-slate-300 mt-1.5">Resources:</strong>
        <ul className="space-y-0.5">
          {item.resources.map((res, i) => (
            <li key={i} className="text-xs">
              <a href={res.url} target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:underline dark:text-sky-400 flex items-center">
                <LinkIcon className="w-3 h-3 mr-1 flex-shrink-0" /> {res.name}
              </a>
            </li>
          ))}
        </ul>
      </>
    )}
  </div>
);

const CoursePlanPage: React.FC = () => {
  const [coursePlans, setCoursePlans] = useState<CoursePlanSubject[]>(mockCoursePlans);
  const [expandedSubject, setExpandedSubject] = useState<string | null>(coursePlans[0]?.subjectName || null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Course Plan & Syllabus</h1>
        <ListBulletIcon className="w-8 h-8 text-sky-500" />
      </div>

      {coursePlans.length > 0 ? (
        <div className="space-y-4">
          {coursePlans.map(subjectPlan => (
            <Card key={subjectPlan.subjectName} className="shadow-lg">
              <button 
                className="w-full p-4 text-left focus:outline-none"
                onClick={() => setExpandedSubject(expandedSubject === subjectPlan.subjectName ? null : subjectPlan.subjectName)}
                aria-expanded={expandedSubject === subjectPlan.subjectName}
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold text-sky-700 dark:text-sky-300 flex items-center">
                    <BookOpenIcon className="w-5 h-5 mr-2 text-sky-600 dark:text-sky-400" />
                    {subjectPlan.subjectName}
                  </h2>
                  <span className={`transform transition-transform duration-200 ${expandedSubject === subjectPlan.subjectName ? 'rotate-180' : 'rotate-0'}`}>
                    ▼ {/* Or use ChevronDownIcon */}
                  </span>
                </div>
              </button>
              {expandedSubject === subjectPlan.subjectName && (
                <div className="px-4 pb-4 border-t dark:border-slate-700 divide-y dark:divide-slate-700">
                  {subjectPlan.items.length > 0 ? (
                    subjectPlan.items.map(item => <CoursePlanItemDisplay key={item.id} item={item} />)
                  ) : (
                    <p className="py-4 text-sm text-slate-500 dark:text-slate-400">No course items available for this subject yet.</p>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      ) : (
         <Card className="shadow-lg">
            <p className="text-slate-500 dark:text-slate-400 text-center py-12">No course plans available at the moment.</p>
        </Card>
      )}
    </div>
  );
};

export default CoursePlanPage;
