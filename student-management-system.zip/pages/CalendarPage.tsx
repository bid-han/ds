
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { CalendarEvent } from '../types';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import ChevronLeftIcon from '../components/icons/ChevronLeftIcon';
import ChevronRightIcon from '../components/icons/ChevronRightIcon';
import CalendarIcon from '../components/icons/CalendarIcon';

const CalendarPage: React.FC = () => {
  const { calendarEvents } = useAppContext();
  const [activeTab, setActiveTab] = useState<'academic' | 'board'>('academic');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay(); // 0 (Sun) - 6 (Sat)

  const currentMonthEvents = useMemo(() => {
    return calendarEvents.filter(event => {
      const eventDate = new Date(event.date);
      return event.calendarType === activeTab &&
             eventDate.getFullYear() === currentDate.getFullYear() &&
             eventDate.getMonth() === currentDate.getMonth();
    });
  }, [calendarEvents, activeTab, currentDate]);

  const renderCalendarGrid = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const numDays = daysInMonth(year, month);
    const firstDay = firstDayOfMonth(year, month);
    const today = new Date();

    const cells = [];
    for (let i = 0; i < firstDay; i++) {
      cells.push(<div key={`empty-${i}`} className="border border-slate-200 dark:border-slate-700 h-24"></div>);
    }

    for (let day = 1; day <= numDays; day++) {
      const dayEvents = currentMonthEvents.filter(event => new Date(event.date).getDate() === day);
      const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
      cells.push(
        <div key={day} className={`relative border border-slate-200 dark:border-slate-700 p-1.5 h-28 sm:h-32 overflow-y-auto
          ${isToday ? 'bg-sky-100 dark:bg-sky-700/30' : 'hover:bg-slate-50 dark:hover:bg-slate-700/20 transition-colors'}`}>
          <span className={`font-medium ${isToday ? 'text-sky-600 dark:text-sky-300' : 'text-slate-700 dark:text-slate-300'}`}>{day}</span>
          <div className="mt-1 space-y-1">
            {dayEvents.map(event => (
              <button
                key={event.id}
                onClick={() => setSelectedEvent(event)}
                className={`w-full text-left p-1 rounded text-xs truncate 
                  ${event.type === 'exam' ? 'bg-red-100 dark:bg-red-800/70 text-red-700 dark:text-red-200' :
                    event.type === 'holiday' ? 'bg-green-100 dark:bg-green-800/70 text-green-700 dark:text-green-200' :
                    event.type === 'assignment' ? 'bg-yellow-100 dark:bg-yellow-800/70 text-yellow-700 dark:text-yellow-200' :
                    'bg-sky-100 dark:bg-sky-800/70 text-sky-700 dark:text-sky-200'}`}
              >
                {event.title}
              </button>
            ))}
          </div>
        </div>
      );
    }
    return cells;
  };
  
  const changeMonth = (offset: number) => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + offset, 1));
  };

  return (
    <div className="space-y-6">
       <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Calendar</h1>
        <CalendarIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card>
        <div className="border-b border-slate-200 dark:border-slate-700">
          <nav className="-mb-px flex space-x-6" aria-label="Tabs">
            {(['academic', 'board'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm capitalize
                  ${activeTab === tab
                    ? 'border-sky-500 text-sky-600 dark:text-sky-400'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:border-slate-600'
                  }`}
              >
                {tab === 'academic' ? 'Academic Calendar' : 'Board Schedule'}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => changeMonth(-1)} className="p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700">
              <ChevronLeftIcon className="w-5 h-5 text-slate-500 dark:text-slate-400" />
            </button>
            <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-200">
              {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
            </h2>
            <button onClick={() => changeMonth(1)} className="p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700">
              <ChevronRightIcon className="w-5 h-5 text-slate-500 dark:text-slate-400" />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-px bg-slate-200 dark:bg-slate-700 border border-slate-200 dark:border-slate-700">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-center py-2 font-medium text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50">{day}</div>
            ))}
            {renderCalendarGrid()}
          </div>
        </div>
      </Card>

      <Modal isOpen={!!selectedEvent} onClose={() => setSelectedEvent(null)} title={selectedEvent?.title}>
        {selectedEvent && (
          <div>
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-2"><strong>Date:</strong> {new Date(selectedEvent.date).toLocaleDateString()}</p>
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-2"><strong>Type:</strong> <span className="capitalize">{selectedEvent.type}</span></p>
            <p className="text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{selectedEvent.description}</p>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default CalendarPage;
