import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { LeaveNote } from '../types';
import { mockLeaveNotes } from '../services/mockData';
import MailIcon from '../components/icons/MailIcon'; // Create this
import LoadingSpinner from '../components/LoadingSpinner';
import UploadIcon from '../components/icons/UploadIcon';

const LeaveNotesPage: React.FC = () => {
  const { currentUser } = useAppContext();
  const [leaveNotes, setLeaveNotes] = useState<LeaveNote[]>(
    mockLeaveNotes.filter(note => note.studentId === currentUser?.id)
  );
  const [showForm, setShowForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Form state
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [reason, setReason] = useState('');
  const [attachment, setAttachment] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachment(e.target.files[0]);
    } else {
      setAttachment(null);
    }
  };

  const handleSubmitLeaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newNote: LeaveNote = {
      id: `ln${leaveNotes.length + 1 + Date.now()}`, // Simple unique ID
      studentId: currentUser.id,
      studentName: currentUser.name,
      fromDate,
      toDate,
      reason,
      status: 'Pending',
      submittedDate: new Date().toISOString().split('T')[0],
      attachmentUrl: attachment ? URL.createObjectURL(attachment) : undefined,
    };
    setLeaveNotes(prev => [newNote, ...prev]);
    
    // Reset form
    setFromDate('');
    setToDate('');
    setReason('');
    setAttachment(null);
    setShowForm(false);
    setIsLoading(false);
    // Show success message ideally
  };

  const getStatusColor = (status: LeaveNote['status']) => {
    if (status === 'Approved') return 'text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-700/30';
    if (status === 'Rejected') return 'text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-700/30';
    return 'text-yellow-600 dark:text-yellow-400 bg-yellow-100 dark:bg-yellow-700/30';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Leave Notes</h1>
        <MailIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        <div className="p-4 flex justify-end">
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2 bg-sky-600 text-white font-semibold rounded-lg shadow hover:bg-sky-700 transition-colors text-sm"
          >
            {showForm ? 'Cancel Request' : 'New Leave Request'}
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmitLeaveNote} className="p-4 border-t border-slate-200 dark:border-slate-700 space-y-4">
            <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">Submit New Leave Request</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="fromDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">From Date</label>
                <input type="date" id="fromDate" value={fromDate} onChange={e => setFromDate(e.target.value)} required 
                       className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
              </div>
              <div>
                <label htmlFor="toDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">To Date</label>
                <input type="date" id="toDate" value={toDate} onChange={e => setToDate(e.target.value)} required 
                       className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white"/>
              </div>
            </div>
            <div>
              <label htmlFor="reason" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Reason for Leave</label>
              <textarea id="reason" value={reason} onChange={e => setReason(e.target.value)} required rows={3}
                        className="mt-1 block w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-sky-500 focus:border-sky-500 sm:text-sm dark:bg-slate-700/50 dark:text-white resize-none"/>
            </div>
             <div>
                <label htmlFor="attachment" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Attach Document (Optional)</label>
                 <div className="mt-1 flex items-center space-x-2 p-3 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg">
                   <UploadIcon className="w-6 h-6 text-slate-400 dark:text-slate-500" />
                  <input 
                    type="file" 
                    id="attachment"
                    onChange={handleFileChange} 
                    className="block w-full text-sm text-slate-500 dark:text-slate-400
                               file:mr-4 file:py-1.5 file:px-3
                               file:rounded-md file:border-0
                               file:text-sm file:font-semibold
                               file:bg-sky-50 file:text-sky-700 dark:file:bg-sky-700/30 dark:file:text-sky-300
                               hover:file:bg-sky-100 dark:hover:file:bg-sky-600/40"
                  />
                </div>
                {attachment && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Selected: {attachment.name}</p>}
            </div>
            <div className="text-right">
              <button type="submit" disabled={isLoading}
                      className="px-6 py-2.5 bg-green-600 hover:bg-green-700 disabled:bg-slate-400 text-white font-semibold rounded-lg shadow hover:shadow-md transition-colors flex items-center justify-center min-w-[120px]">
                {isLoading ? <LoadingSpinner size="h-5 w-5" /> : 'Submit Request'}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 border-t border-slate-200 dark:border-slate-700">
          <h3 className="p-4 text-lg font-semibold text-slate-700 dark:text-slate-200">Submitted Leave Notes</h3>
          {leaveNotes.length > 0 ? (
            <ul className="divide-y divide-slate-200 dark:divide-slate-700">
              {leaveNotes.map(note => (
                <li key={note.id} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                    <div>
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Dates: {new Date(note.fromDate).toLocaleDateString()} to {new Date(note.toDate).toLocaleDateString()}
                      </p>
                      <p className="text-slate-600 dark:text-slate-300 mt-1">Reason: {note.reason}</p>
                      {note.attachmentUrl && (
                        <a href={note.attachmentUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-sky-600 hover:underline dark:text-sky-400 mt-1 inline-block">View Attachment</a>
                      )}
                    </div>
                    <div className="mt-2 sm:mt-0 sm:text-right">
                        <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(note.status)}`}>
                            {note.status}
                        </span>
                        <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Submitted: {new Date(note.submittedDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-slate-500 dark:text-slate-400 text-center py-8">No leave notes submitted yet.</p>
          )}
        </div>
      </Card>
    </div>
  );
};

export default LeaveNotesPage;
