
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import Card from '../components/ui/Card';
import { TimetableEntry } from '../types';
import { mockTimetable } from '../services/mockData';
import TableIcon from '../components/icons/TableIcon'; // Create this

const TimetablePage: React.FC = () => {
  const { currentUser } = useAppContext();
  // For a real app, you might fetch timetable based on currentUser.class
  const [timetable, setTimetable] = useState<TimetableEntry[]>(mockTimetable);

  const daysOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  
  const groupedTimetable = timetable.reduce((acc, entry) => {
    (acc[entry.day] = acc[entry.day] || []).push(entry);
    return acc;
  }, {} as Record<string, TimetableEntry[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Class Timetable</h1>
        <TableIcon className="w-8 h-8 text-sky-500" />
      </div>

      <Card className="shadow-lg">
        {Object.keys(groupedTimetable).length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 border border-slate-200 dark:border-slate-700">
              <thead className="bg-slate-50 dark:bg-slate-700/50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider border-r dark:border-slate-600">Time</th>
                  {daysOrder.map(day => (
                     (groupedTimetable[day] || []).length > 0 && // Only show day if there are entries
                    <th key={day} scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider border-r dark:border-slate-600 last:border-r-0">{day}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                {/* This part needs dynamic generation based on unique time slots. For simplicity, we'll assume fixed slots or map existing ones. */}
                {/* A more robust solution would identify all unique time slots first. */}
                {Array.from(new Set(timetable.map(e => e.time))).sort().map(timeSlot => (
                  <tr key={timeSlot} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                    <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-700 dark:text-slate-200 border-r dark:border-slate-600">{timeSlot}</td>
                    {daysOrder.map(day => {
                      // Fix: Corrected operator precedence. `!array.length > 0` was parsed as `(!array.length) > 0`.
                      // Changed to check if length is explicitly zero to avoid rendering a cell for days with no entries, consistent with header logic.
                      if ((groupedTimetable[day] || []).length === 0) return null;
                      const entry = groupedTimetable[day]?.find(e => e.time === timeSlot);
                      return (
                        <td key={`${day}-${timeSlot}`} className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300 border-r dark:border-slate-600 last:border-r-0">
                          {entry ? (
                            <div>
                              <p className="font-semibold">{entry.subject}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400">{entry.teacher}</p>
                              {entry.room && <p className="text-xs text-slate-400 dark:text-slate-500">Room: {entry.room}</p>}
                            </div>
                          ) : (
                            '-'
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-slate-500 dark:text-slate-400 text-center py-8">No timetable information available.</p>
        )}
      </Card>
      <p className="text-xs text-center text-slate-400 dark:text-slate-500">
        Note: Timetable is subject to change. Please check with the school office for the latest updates.
      </p>
    </div>
  );
};

export default TimetablePage;
