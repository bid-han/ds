
import React from 'react';

const LoadingSpinner: React.FC<{ size?: string }> = ({ size = "h-5 w-5" }) => (
  <div className={`animate-spin rounded-full border-t-2 border-b-2 border-sky-500 ${size}`}></div>
);

export default LoadingSpinner;
