import React from 'react';

const UploadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.5 3.75a.75.75 0 01.75.75v6.19l1.97-1.97a.75.75 0 111.06 1.06l-3.5 3.5a.75.75 0 01-1.06 0l-3.5-3.5a.75.75 0 111.06-1.06l1.97 1.97V4.5a.75.75 0 01.75-.75zM3.75 12.75A.75.75 0 013 12V8.25a.75.75 0 011.5 0V12a.75.75 0 01-.75.75zm16.5 0a.75.75 0 01-.75-.75V8.25a.75.75 0 011.5 0V12a.75.75 0 01-.75.75z" clipRule="evenodd" />
    <path d="M12 15a.75.75 0 00-.75.75v3.75H8.25A2.25 2.25 0 006 21.75h12A2.25 2.25 0 0015.75 19.5H12.75V15.75A.75.75 0 0012 15z" />
  </svg>
);

export default UploadIcon;