
import React from 'react';

const BellIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M11.49 3.001a.75.75 0 01.996-.031 10.523 10.523 0 018.025 10.493.75.75 0 01-.38.699A1.99 1.99 0 0021 16.008c0 1.102-.89 1.992-1.992 1.992H4.992A1.992 1.992 0 013 16.008c0-.314.07-.618.203-.895a.75.75 0 01-.38-.7A10.523 10.523 0 0111.02.271a.75.75 0 01.47-.27zm.293 17.25a3.001 3.001 0 002.995-2.25H8.788a3.001 3.001 0 002.995 2.25z" clipRule="evenodd" />
  </svg>
);

export default BellIcon;
