import React from 'react';

const RssIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M3.75 3.75a.75.75 0 00-.75.75v2.25c0 .414.336.75.75.75h2.25a.75.75 0 00.75-.75V6h9a.75.75 0 000-1.5h-9V4.5a.75.75 0 00-.75-.75H3.75z" />
    <path fillRule="evenodd" d="M3 11.25a1.5 1.5 0 011.5-1.5h15a1.5 1.5 0 011.5 1.5v9.75a1.5 1.5 0 01-1.5 1.5h-15A1.5 1.5 0 013 21V11.25zm1.5.75v2.25c0 .414.336.75.75.75h13.5a.75.75 0 00.75-.75V12c0-.414-.336-.75-.75-.75H4.5z" clipRule="evenodd" />
    <path d="M3.75 17.25a.75.75 0 00-.75.75v2.25c0 .414.336.75.75.75h2.25a.75.75 0 00.75-.75V19.5h9a.75.75 0 000-1.5h-9v-.75a.75.75 0 00-.75-.75H3.75z" />
  </svg>
);

export default RssIcon;
