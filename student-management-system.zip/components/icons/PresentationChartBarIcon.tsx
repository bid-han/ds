
import React from 'react';

const PresentationChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2.25 2.25a.75.75 0 00-.75.75v11.25c0 .414.336.75.75.75h2.25a.75.75 0 00.75-.75V15h13.5v-1.5H15a.75.75 0 00-.75.75v1.5H5.25v-1.5a.75.75 0 00-.75-.75H3V6.75A.75.75 0 013.75 6H15v1.5a.75.75 0 001.5 0V6h3.75a.75.75 0 01.75.75v3a.75.75 0 001.5 0V3a.75.75 0 00-.75-.75H2.25zm6.547 15.56a.75.75 0 01.087-1.057l3-3.75a.75.75 0 011.13.914l-2.264 2.83 2.264 2.83a.75.75 0 01-1.13.915l-3-3.75a.75.75 0 01.086-.012zM15.547 9.56a.75.75 0 01.087-1.057l3-3.75a.75.75 0 111.13.914l-2.264 2.83 2.264 2.83a.75.75 0 11-1.13.915l-3-3.75a.75.75 0 01.086-.012z" clipRule="evenodd" />
    <path d="M5.25 17.25a.75.75 0 00-.75.75v2.25c0 .414.336.75.75.75H18a.75.75 0 00.75-.75V18a.75.75 0 00-.75-.75H5.25z" />
  </svg>
);

export default PresentationChartBarIcon;
