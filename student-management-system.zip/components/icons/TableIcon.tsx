import React from 'react';

const TableIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M4.5 3A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3h-15zm0 9v6h15v-6h-15zm0-7.5h15V9h-15V4.5zM7.5 16.5a.75.75 0 000-1.5H6v1.5h1.5zM16.5 12a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3a.75.75 0 01.75-.75z" clipRule="evenodd" />
    <path d="M9 7.5a.75.75 0 01-.75-.75V6a.75.75 0 011.5 0v.75A.75.75 0 019 7.5zm3 0a.75.75 0 01-.75-.75V6a.75.75 0 011.5 0v.75A.75.75 0 0112 7.5zm3 0a.75.75 0 01-.75-.75V6a.75.75 0 011.5 0v.75A.75.75 0 0115 7.5z" />
  </svg>
);

export default TableIcon;