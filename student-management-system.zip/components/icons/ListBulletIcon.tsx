import React from 'react';

const ListBulletIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M2.625 6.75a.75.75 0 01.75-.75h.01a.75.75 0 010 1.5H3.375a.75.75 0 01-.75-.75zM2.625 12a.75.75 0 01.75-.75h.01a.75.75 0 010 1.5H3.375a.75.75 0 01-.75-.75zM2.625 17.25a.75.75 0 01.75-.75h.01a.75.75 0 010 1.5H3.375a.75.75 0 01-.75-.75zM6.375 6.75a.75.75 0 01.75-.75h13.5a.75.75 0 010 1.5H7.125a.75.75 0 01-.75-.75zM6.375 12a.75.75 0 01.75-.75h13.5a.75.75 0 010 1.5H7.125a.75.75 0 01-.75-.75zM6.375 17.25a.75.75 0 01.75-.75h13.5a.75.75 0 010 1.5H7.125a.75.75 0 01-.75-.75z" clipRule="evenodd" />
  </svg>
);

export default ListBulletIcon;
