import React from 'react';

const AcademicCapIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M3.375 6.75c0-1.036.84-1.875 1.875-1.875h13.5c1.036 0 1.875.84 1.875 1.875v3.375c0 .478-.195.927-.514 1.246L12 18.75l-7.86-7.38A1.875 1.875 0 013.375 10.125V6.75zM12 15.431 18.36 9.68V6.75H5.64v2.93L12 15.43z" />
    <path d="M12 21.75l2.217-1.663a.75.75 0 00-.021-1.286l-1.323-.882A.75.75 0 0012 17.25v-2.43a.75.75 0 00-1.5 0V17.25a.75.75 0 00-.373.669l-1.323.882a.75.75 0 00-.021 1.286L12 21.75z" />
  </svg>
);

export default AcademicCapIcon;