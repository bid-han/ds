import React from 'react';

const VideoCameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M4.5 4.5a3 3 0 00-3 3v9a3 3 0 003 3h8.25a3 3 0 003-3v-2.845l3.508 2.34a.75.75 0 001.242-.6V7.505a.75.75 0 00-1.242-.601L15.75 9.345V7.5a3 3 0 00-3-3H4.5z" />
  </svg>
);

export default VideoCameraIcon;
