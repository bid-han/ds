import React from 'react';

const DocumentTextIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M5.625 1.5A3.375 3.375 0 002.25 4.875v14.25A3.375 3.375 0 005.625 22.5h12.75A3.375 3.375 0 0021.75 19.125V4.875A3.375 3.375 0 0018.375 1.5H5.625zM12.75 6a.75.75 0 00-1.5 0v2.25H9a.75.75 0 000 1.5h2.25V12a.75.75 0 001.5 0V9.75h2.25a.75.75 0 000-1.5H12.75V6z" clipRule="evenodd" />
    <path d="M8.25 13.5a.75.75 0 01.75-.75h6a.75.75 0 010 1.5h-6a.75.75 0 01-.75-.75zm0 3a.75.75 0 01.75-.75h6a.75.75 0 010 1.5h-6a.75.75 0 01-.75-.75zM8.25 19.5a.75.75 0 01.75-.75h6a.75.75 0 010 1.5h-6a.75.75 0 01-.75-.75z" />
  </svg>
);

export default DocumentTextIcon;