import React from 'react';

const ClipboardCheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.5 3A2.25 2.25 0 008.25 5.25v.033A2.25 2.25 0 0110.5 3zm2.25 0A2.25 2.25 0 0010.5 5.283V5.25A2.25 2.25 0 0112.75 3z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M6.75 6.75A.75.75 0 017.5 6h9a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-9a.75.75 0 01-.75-.75V6.75zM5.25 6.75A2.25 2.25 0 003 9v8.25A2.25 2.25 0 005.25 19.5h13.5A2.25 2.25 0 0021 17.25V9A2.25 2.25 0 0018.75 6.75H5.25z" clipRule="evenodd" />
    <path fillRule="evenodd" d="M10.01 11.06a.75.75 0 011.06-.053l1.736 1.656 2.618-2.877a.75.75 0 111.136.976l-3.125 3.437a.75.75 0 01-1.11.026L10.06 12.12a.75.75 0 01-.053-1.06z" clipRule="evenodd" />
  </svg>
);

export default ClipboardCheckIcon;
