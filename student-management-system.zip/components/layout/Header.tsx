
import React, { useState } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import UserIcon from '../icons/UserIcon';
import BellIcon from '../icons/BellIcon';
import LogoutIcon from '../icons/LogoutIcon';
import SunIcon from '../icons/SunIcon';
import MoonIcon from '../icons/MoonIcon';
import MenuIcon from '../icons/MenuIcon';
import CogIcon from '../icons/CogIcon';

const Header: React.FC = () => {
  const { 
    currentUser, 
    logout, 
    theme, 
    setTheme, 
    getUnreadNotificationCount, 
    setCurrentPage,
    toggleSidebar,
    isSidebarOpen 
  } = useAppContext();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const unreadCount = getUnreadNotificationCount();

  const handleThemeToggle = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <header className={`sticky top-0 z-30 bg-white dark:bg-slate-800 shadow-md dark:shadow-slate-700 transition-all duration-300 ease-in-out ${isSidebarOpen ? "lg:ml-64" : "lg:ml-20"}`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button
              onClick={toggleSidebar}
              className="text-slate-500 dark:text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              aria-label="Toggle sidebar"
            >
              <MenuIcon className="w-6 h-6" />
            </button>
          </div>
          
          {/* Placeholder for search or title on larger screens if needed */}
          <div className="hidden lg:block">
             <h1 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Student Portal</h1>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleThemeToggle}
              className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <MoonIcon className="w-5 h-5" /> : <SunIcon className="w-5 h-5" />}
            </button>

            <button 
              className="relative p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              onClick={() => setCurrentPage('notifications')}
              aria-label="Notifications"
            >
              <BellIcon className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-0 right-0 block h-4 w-4 rounded-full ring-2 ring-white dark:ring-slate-800 bg-red-500 text-xs text-white flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center space-x-2 p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"
                aria-haspopup="true"
                aria-expanded={userMenuOpen}
              >
                {currentUser?.profilePictureUrl ? (
                  <img src={currentUser.profilePictureUrl} alt="User" className="w-8 h-8 rounded-full" />
                ) : (
                  <UserIcon className="w-8 h-8 p-1 text-slate-500 dark:text-slate-400 rounded-full bg-slate-200 dark:bg-slate-600" />
                )}
                <span className="hidden md:inline text-sm text-slate-700 dark:text-slate-300">{currentUser?.name}</span>
              </button>
              {userMenuOpen && (
                <div 
                    className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white dark:bg-slate-700 ring-1 ring-black ring-opacity-5 focus:outline-none"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="user-menu-button"
                >
                  <button
                    onClick={() => { setCurrentPage('profile'); setUserMenuOpen(false); }}
                    className="flex items-center w-full px-4 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600"
                    role="menuitem"
                  >
                    <UserIcon className="w-4 h-4 mr-2" /> Profile
                  </button>
                  <button
                    onClick={() => { setCurrentPage('settings'); setUserMenuOpen(false); }}
                    className="flex items-center w-full px-4 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600"
                    role="menuitem"
                  >
                    <CogIcon className="w-4 h-4 mr-2" /> Settings
                  </button>
                  <hr className="border-slate-200 dark:border-slate-600 my-1" />
                  <button
                    onClick={() => { logout(); setUserMenuOpen(false); }}
                    className="flex items-center w-full px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-slate-100 dark:hover:bg-slate-600"
                    role="menuitem"
                  >
                    <LogoutIcon className="w-4 h-4 mr-2" /> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
