
import React, { useState } from 'react';
import { useAppContext } from '../../contexts/AppContext';
import { MenuItem } from '../../types';
import HomeIcon from '../icons/HomeIcon';
import BellIcon from '../icons/BellIcon';
import CalendarIcon from '../icons/CalendarIcon';
import UserIcon from '../icons/UserIcon';
import BookOpenIcon from '../icons/BookOpenIcon';
import ClipboardListIcon from '../icons/ClipboardListIcon';
import PresentationChartBarIcon from '../icons/PresentationChartBarIcon';
import CogIcon from '../icons/CogIcon';
import InformationCircleIcon from '../icons/InformationCircleIcon';
import ChevronDownIcon from '../icons/ChevronDownIcon';
import ChevronRightIcon from '../icons/ChevronRightIcon';
import MenuIcon from '../icons/MenuIcon'; // For brand logo placeholder
import CloseIcon from '../icons/CloseIcon';

const menuItems: MenuItem[] = [
  { id: 'dash', label: 'Dashboard', icon: HomeIcon, page: 'dashboard' },
  { id: 'notifications', label: 'Notifications', icon: BellIcon, page: 'notifications' },
  { id: 'calendar', label: 'Calendar', icon: CalendarIcon, page: 'calendar' },
  { id: 'academics', label: 'Academics', icon: BookOpenIcon, page: 'academics_group', children: [
      { id: 'account', label: 'Student Account', page: 'account' },
      { id: 'online-classes', label: 'Online Classes', page: 'online-classes' },
      { id: 'assignments', label: 'Assignments', page: 'assignments' },
      { id: 'attendance', label: 'Attendance', page: 'attendance' },
      { id: 'homework-tracker', label: 'Homework Tracker', page: 'homework-tracker' },
      { id: 'report-cards', label: 'Report Cards', page: 'report-cards' },
      { id: 'timetable', label: 'Class Routine', page: 'timetable' },
    ]},
  { id: 'resources', label: 'Resources', icon: ClipboardListIcon, page: 'resources_group', children: [
      { id: 'reading-materials', label: 'Reading Materials', page: 'reading-materials' },
      { id: 'school-events', label: 'School Events', page: 'school-events' },
      { id: 'media-gallery', label: 'Media Gallery', page: 'media-gallery' },
      { id: 'library-access', label: 'Library Access', page: 'library-access' },
      { id: 'downloads', label: 'Downloads', page: 'downloads' },
      { id: 'educational-videos', label: 'Educational Videos', page: 'educational-videos' },
    ]},
  { id: 'communication', label: 'Communication', icon: PresentationChartBarIcon, page: 'communication_group', children: [
      { id: 'blog', label: 'Blog', page: 'blog' },
      { id: 'leave-notes', label: 'Leave Notes', page: 'leave-notes' },
      { id: 'suggestions', label: 'Suggestions', page: 'suggestions' },
    ]},
  { id: 'profile_settings', label: 'Account', icon: UserIcon, page: 'profile_settings_group', children: [
      { id: 'profile', label: 'My Profile', page: 'profile' },
      { id: 'appreciations', label: 'Appreciations', page: 'appreciations' },
      { id: 'documents-uploads', label: 'Documents Uploads', page: 'documents-uploads' },
      { id: 'academic-records', label: 'Academic Records', page: 'academic-records' },
      { id: 'course-plan', label: 'Course Plan', page: 'course-plan' },
    ]},
  { id: 'separator', label: 'separator', page: 'separator' }, // Visual separator
  { id: 'settings', label: 'Settings', icon: CogIcon, page: 'settings' },
  { id: 'about-us', label: 'About Us', icon: InformationCircleIcon, page: 'about-us' },
];

const SidebarMenuItem: React.FC<{ item: MenuItem; isSidebarOpen: boolean; isSubmenu?: boolean }> = ({ item, isSidebarOpen, isSubmenu = false }) => {
  const { currentPage, setCurrentPage, setSidebarOpen: closeMobileSidebar } = useAppContext();
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);
  const isActive = item.children ? item.children.some(child => child.page === currentPage) : currentPage === item.page;
  
  const Icon = item.icon;

  const handleItemClick = () => {
    if (item.children) {
      setIsSubmenuOpen(!isSubmenuOpen);
    } else {
      setCurrentPage(item.page);
      if (window.innerWidth < 1024) { // Close sidebar on mobile after navigation
        closeMobileSidebar(false);
      }
    }
  };

  if (item.page === 'separator') {
    return <hr className={`my-2 border-slate-200 dark:border-slate-700 ${!isSidebarOpen && 'mx-auto w-1/2'}`} />;
  }

  return (
    <>
      <button
        onClick={handleItemClick}
        className={`w-full flex items-center text-sm py-2.5 px-4 rounded-md transition-colors duration-150
                    ${isSubmenu ? (isSidebarOpen ? 'pl-10' : 'pl-4') : (isSidebarOpen ? 'pl-4' : 'justify-center')}
                    ${isActive ? 'bg-sky-500 text-white' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-700 dark:hover:text-slate-200'}`}
        title={isSidebarOpen ? '' : item.label}
      >
        {Icon && <Icon className={`w-5 h-5 ${isSidebarOpen ? 'mr-3' : 'mx-auto'}`} />}
        {isSidebarOpen && <span className="flex-1 text-left">{item.label}</span>}
        {isSidebarOpen && item.children && (
          isSubmenuOpen ? <ChevronDownIcon className="w-4 h-4" /> : <ChevronRightIcon className="w-4 h-4" />
        )}
      </button>
      {isSidebarOpen && isSubmenuOpen && item.children && (
        <div className="mt-1 space-y-1">
          {item.children.map(child => (
            <SidebarMenuItem key={child.id} item={child} isSidebarOpen={isSidebarOpen} isSubmenu={true} />
          ))}
        </div>
      )}
    </>
  );
};

const Sidebar: React.FC = () => {
  const { isSidebarOpen, toggleSidebar, setSidebarOpen } = useAppContext();
  
  return (
    <>
      {/* Overlay for mobile */}
      {isSidebarOpen && window.innerWidth < 1024 && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}

      <aside 
        className={`fixed lg:static inset-y-0 left-0 z-40 bg-white dark:bg-slate-800 shadow-lg lg:shadow-none
                    transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 
                    transition-all duration-300 ease-in-out
                    ${isSidebarOpen ? 'w-64' : 'w-20'} flex flex-col`}
      >
        <div className={`flex items-center ${isSidebarOpen ? 'justify-between px-4' : 'justify-center'} h-16 border-b border-slate-200 dark:border-slate-700`}>
          {isSidebarOpen && (
            <div className="flex items-center">
              <MenuIcon className="w-8 h-8 text-sky-500" /> 
              <span className="ml-2 text-xl font-semibold text-slate-700 dark:text-slate-200">School</span>
            </div>
          )}
           {!isSidebarOpen && (
             <MenuIcon className="w-8 h-8 text-sky-500" /> 
           )}
          <button 
            onClick={toggleSidebar} 
            className="lg:hidden p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md"
            aria-label={isSidebarOpen ? "Close sidebar" : "Open sidebar"}
          >
            {isSidebarOpen ? <CloseIcon className="w-6 h-6"/> : <MenuIcon className="w-6 h-6"/> }
          </button>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {menuItems.map(item => (
            <SidebarMenuItem key={item.id} item={item} isSidebarOpen={isSidebarOpen} />
          ))}
        </nav>
        <div className={`p-4 border-t border-slate-200 dark:border-slate-700 ${!isSidebarOpen && 'hidden'}`}>
          <p className="text-xs text-center text-slate-400 dark:text-slate-500">
            &copy; {new Date().getFullYear()} School Name
          </p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
