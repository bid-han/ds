import React from 'react';
import { AppProvider, useAppContext } from './contexts/AppContext';
import LoginPage from './pages/LoginPage';
import MainLayout from './components/layout/MainLayout';
import DashboardPage from './pages/DashboardPage';
import NotificationsPage from './pages/NotificationsPage';
import CalendarPage from './pages/CalendarPage';
import ProfilePage from './pages/ProfilePage';
import SettingsPage from './pages/SettingsPage';
import AboutUsPage from './pages/AboutUsPage';
import PlaceholderPage from './pages/PlaceholderPage';

// Import new pages
import StudentAccountPage from './pages/StudentAccountPage';
import AssignmentsPage from './pages/AssignmentsPage';
import AttendancePage from './pages/AttendancePage';
import ReportCardsPage from './pages/ReportCardsPage';
import TimetablePage from './pages/TimetablePage';
import LeaveNotesPage from './pages/LeaveNotesPage';
import DocumentsUploadsPage from './pages/DocumentsUploadsPage';
import ReadingMaterialsPage from './pages/ReadingMaterialsPage';
import SchoolEventsPage from './pages/SchoolEventsPage';
import MediaGalleryPage from './pages/MediaGalleryPage';
import LibraryAccessPage from './pages/LibraryAccessPage';
import DownloadsPage from './pages/DownloadsPage';
import EducationalVideosPage from './pages/EducationalVideosPage';
import BlogPage from './pages/BlogPage';
import SuggestionsPage from './pages/SuggestionsPage';
import AppreciationsPage from './pages/AppreciationsPage';
import AcademicRecordsPage from './pages/AcademicRecordsPage';
import CoursePlanPage from './pages/CoursePlanPage';
import OnlineClassesPage from './pages/OnlineClassesPage';
import HomeworkTrackerPage from './pages/HomeworkTrackerPage';


// Define a mapping from page keys to components
export const PageComponents: Record<string, React.FC> = {
  dashboard: DashboardPage,
  notifications: NotificationsPage,
  calendar: CalendarPage,
  account: StudentAccountPage,
  'online-classes': OnlineClassesPage,
  assignments: AssignmentsPage,
  attendance: AttendancePage,
  'homework-tracker': HomeworkTrackerPage,
  'report-cards': ReportCardsPage,
  timetable: TimetablePage,
  'reading-materials': ReadingMaterialsPage,
  'school-events': SchoolEventsPage,
  'media-gallery': MediaGalleryPage,
  'library-access': LibraryAccessPage,
  downloads: DownloadsPage,
  'educational-videos': EducationalVideosPage,
  blog: BlogPage,
  'leave-notes': LeaveNotesPage,
  suggestions: SuggestionsPage,
  appreciations: AppreciationsPage,
  'documents-uploads': DocumentsUploadsPage,
  'academic-records': AcademicRecordsPage,
  'course-plan': CoursePlanPage,
  profile: ProfilePage,
  'about-us': AboutUsPage,
  settings: SettingsPage,
};


const AppContent: React.FC = () => {
  const { isLoggedIn, currentPage } = useAppContext();

  if (!isLoggedIn) {
    return <LoginPage />;
  }

  const CurrentPageComponent = PageComponents[currentPage] || DashboardPage;

  return (
    <MainLayout>
      <CurrentPageComponent />
    </MainLayout>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;