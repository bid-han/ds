import { UserProfile, NotificationItem, CalendarEvent, StudentAccountDetails, Assignment, AttendanceRecord, ReportCardSummary, TimetableEntry, LeaveNote, StudentDocument, ReadingMaterial, MediaItem, LibraryBook, DownloadableFile, EducationalVideo, BlogPost, Suggestion, Appreciation, AcademicRecordItem, CoursePlanSubject } from '../types';

export const mockUser: UserProfile = {
  id: 'user001',
  name: 'Alex Johnson',
  username: 'alex.j',
  email: 'alex.johnson@example.com',
  class: '10th Grade',
  section: 'A',
  profilePictureUrl: 'https://randomuser.me/api/portraits/men/32.jpg', // Placeholder image
  feesDue: 0, // Updated by mockStudentAccount
  rollNumber: 'S10A-023',
  admissionDate: '2020-04-01',
};

export const mockNotifications: NotificationItem[] = [
  { id: 'n1', type: 'personal', title: 'Absence Report', message: 'You were marked absent on Oct 26th. Please submit a leave note.', date: '2024-10-27T10:00:00Z', read: false },
  { id: 'n2', type: 'general', title: 'Holiday Announcement', message: 'School will be closed on Nov 1st for a public holiday.', date: '2024-10-25T14:30:00Z', read: true },
  { id: 'n3', type: 'personal', title: 'Assignment Graded', message: 'Your Math assignment "Algebra II" has been graded. Score: 85/100.', date: '2024-10-28T09:15:00Z', read: false, link: '#' },
  { id: 'n4', type: 'general', title: 'Parent-Teacher Meeting', message: 'Parent-Teacher meetings are scheduled for Nov 15th-17th. Sign up now.', date: '2024-10-20T11:00:00Z', read: true },
  { id: 'n5', type: 'personal', title: 'Library Book Due', message: 'Your borrowed book "The Great Gatsby" is due on Nov 5th.', date: '2024-10-29T16:00:00Z', read: false },
];

export const mockCalendarEvents: CalendarEvent[] = [
  { id: 'e1', date: '2024-11-05', title: 'Mid-Term Exams Start', description: 'Mid-term examinations for all grades commence.', type: 'exam', calendarType: 'board' },
  { id: 'e2', date: '2024-11-10', title: 'Science Fair', description: 'Annual school science fair. Submissions due Nov 1st.', type: 'event', calendarType: 'academic' },
  { id: 'e3', date: '2024-11-01', title: 'Public Holiday', description: 'School closed for public holiday.', type: 'holiday', calendarType: 'academic' },
  { id: 'e4', date: '2024-11-15', title: 'Math Assignment Due', description: 'Chapter 5 problems from Algebra textbook.', type: 'assignment', calendarType: 'academic' },
  { id: 'e5', date: '2024-12-20', title: 'Winter Break Begins', description: 'School closed for winter vacation.', type: 'holiday', calendarType: 'academic' },
  { id: 'e6', date: '2024-11-25', title: 'History Project Presentation', description: 'Presentations for World War II projects.', type: 'event', calendarType: 'academic' },
  { id: 'e7', date: new Date().toISOString().split('T')[0], title: 'Today\'s Special Assembly', description: 'Special assembly on environmental awareness.', type: 'event', calendarType: 'academic' },
  { id: 'e8', date: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split('T')[0], title: 'Upcoming Quiz', description: 'Physics quiz on Chapter 3.', type: 'exam', calendarType: 'board' },
];

export const mockStudentAccount: StudentAccountDetails = {
  ...mockUser,
  totalFees: 5000,
  paidFees: 4800,
  balance: 200,
  feesDue: 200, // Overrides mockUser one
  paymentHistory: [
    { id: 'p1', date: '2024-04-05', amount: 2500, method: 'Online Transfer', transactionId: 'TXN123456789' },
    { id: 'p2', date: '2024-07-10', amount: 2300, method: 'Bank Deposit', transactionId: 'TXN987654321' },
  ],
};

export const mockAssignments: Assignment[] = [
  { id: 'a1', subject: 'Mathematics', title: 'Algebra II Worksheet', description: 'Complete exercises 1-10 from Chapter 5.', assignedDate: '2024-10-20', dueDate: '2024-11-05', status: 'Pending' },
  { id: 'a2', subject: 'Science', title: 'Photosynthesis Lab Report', description: 'Submit a detailed lab report on the photosynthesis experiment.', assignedDate: '2024-10-15', dueDate: '2024-10-28', status: 'Graded', grade: 'A', fileUrl: '#' },
  { id: 'a3', subject: 'History', title: 'World War II Essay', description: 'Write a 1000-word essay on the causes of WWII.', assignedDate: '2024-09-25', dueDate: '2024-10-25', status: 'Graded', grade: '88/100', fileUrl: '#' },
  { id: 'a4', subject: 'English', title: 'Book Review: To Kill a Mockingbird', description: 'Submit a 500-word review of the novel.', assignedDate: '2024-11-01', dueDate: '2024-11-15', status: 'Pending' },
];

export const mockAttendance: AttendanceRecord[] = [
  { 
    month: 'October 2024', 
    totalDays: 22, 
    presentDays: 20, 
    absentDays: 2, 
    percentage: 90.9,
    dailyRecords: [
        { date: '2024-10-01', status: 'Present'}, { date: '2024-10-02', status: 'Present'}, { date: '2024-10-03', status: 'Absent'},
        // ... more days
        { date: '2024-10-26', status: 'Absent'}, { date: '2024-10-27', status: 'Present'},
    ]
  },
  { month: 'September 2024', totalDays: 21, presentDays: 21, absentDays: 0, percentage: 100 },
];

export const mockReportCards: ReportCardSummary[] = [
  { 
    id: 'rc1', 
    term: 'Mid-Term 2024', 
    issueDate: '2024-08-15', 
    overallPercentage: 88.5, 
    overallGrade: 'A',
    subjects: [
      { name: 'Mathematics', marksObtained: 90, totalMarks: 100, grade: 'A+' },
      { name: 'Science', marksObtained: 85, totalMarks: 100, grade: 'A' },
      { name: 'English', marksObtained: 82, totalMarks: 100, grade: 'A-' },
      { name: 'History', marksObtained: 92, totalMarks: 100, grade: 'A+' },
      { name: 'Computer Science', marksObtained: 93, totalMarks: 100, grade: 'A+' },
    ],
    downloadUrl: '#',
    teacherComments: "Alex is a diligent student and shows great potential. Keep up the good work!",
    principalComments: "Excellent performance, Alex. We are proud of your achievements."
  },
];

export const mockTimetable: TimetableEntry[] = [
  { id: 'tt1', day: 'Monday', time: '09:00 AM - 09:50 AM', subject: 'Mathematics', teacher: 'Ms. Davison', room: '101' },
  { id: 'tt2', day: 'Monday', time: '10:00 AM - 10:50 AM', subject: 'Science', teacher: 'Mr. Lee', room: 'Lab A' },
  { id: 'tt3', day: 'Tuesday', time: '09:00 AM - 09:50 AM', subject: 'English', teacher: 'Mrs. Peters', room: '102' },
  // Add more entries for a full week
];

export const mockLeaveNotes: LeaveNote[] = [
    { id: 'ln1', studentId: 'user001', studentName: 'Alex Johnson', fromDate: '2024-10-26', toDate: '2024-10-26', reason: 'Fever and flu symptoms.', status: 'Approved', submittedDate: '2024-10-27' },
    { id: 'ln2', studentId: 'user001', studentName: 'Alex Johnson', fromDate: '2024-11-10', toDate: '2024-11-12', reason: 'Family function out of station.', status: 'Pending', submittedDate: '2024-11-01' },
];

export const mockStudentDocuments: StudentDocument[] = [
    { id: 'doc1', name: 'Birth Certificate', type: 'ID Card', uploadDate: '2020-04-01', fileUrl: '#', size: '1.2MB' },
    { id: 'doc2', name: 'Previous School Report Card', type: 'Report', uploadDate: '2020-04-01', fileUrl: '#', size: '850KB' },
    { id: 'doc3', name: 'Vaccination Certificate', type: 'Certificate', uploadDate: '2023-05-15', fileUrl: '#', size: '500KB' },
];

export const mockReadingMaterials: ReadingMaterial[] = [
  { id: 'rm1', title: 'The Adventures of Tom Sawyer', subject: 'English', type: 'PDF', url: '#', addedDate: '2024-09-10' },
  { id: 'rm2', title: 'Introduction to Physics Notes', subject: 'Science', type: 'Notes', url: '#', addedDate: '2024-09-15' },
];

export const mockMediaItems: MediaItem[] = [
  { id: 'mi1', title: 'Annual Sports Day 2023', type: 'image', url: 'https://via.placeholder.com/300x200.png?text=Sports+Day+1', thumbnailUrl: 'https://via.placeholder.com/150x100.png?text=Sports+Day+1', eventDate: '2023-03-15' },
  { id: 'mi2', title: 'Science Fair Highlights', type: 'video', url: '#', thumbnailUrl: 'https://via.placeholder.com/150x100.png?text=Science+Fair+Video', eventDate: '2023-11-10' },
];

export const mockLibraryBooks: LibraryBook[] = [
  { id: 'lb1', title: '1984', author: 'George Orwell', isbn: '978-0451524935', genre: 'Dystopian', availableCopies: 3, totalCopies: 5, coverImageUrl: 'https://via.placeholder.com/100x150.png?text=1984' },
  { id: 'lb2', title: 'Sapiens: A Brief History of Humankind', author: 'Yuval Noah Harari', isbn: '978-0062316097', genre: 'Non-Fiction', availableCopies: 1, totalCopies: 3, coverImageUrl: 'https://via.placeholder.com/100x150.png?text=Sapiens' },
];

export const mockDownloadableFiles: DownloadableFile[] = [
  { id: 'df1', name: 'Leave Application Form', category: 'Form', url: '#', size: '120KB', uploadDate: '2023-01-10' },
  { id: 'df2', name: 'Grade 10 Syllabus - 2024-25', category: 'Syllabus', url: '#', size: '1.5MB', uploadDate: '2024-03-15' },
];

export const mockEducationalVideos: EducationalVideo[] = [
  { id: 'ev1', title: 'Introduction to Calculus', subject: 'Mathematics', description: 'A beginner-friendly introduction to the concepts of calculus.', url: '#', thumbnailUrl: 'https://via.placeholder.com/150x100.png?text=Calculus+Intro', duration: '12:35', uploadedBy: 'Khan Academy (Example)' },
];

export const mockBlogPosts: BlogPost[] = [
  { id: 'bp1', title: 'Welcome to the New School Year!', author: 'Principal Thompson', publishDate: '2024-08-15', excerpt: 'A warm welcome to all students and faculty for the 2024-2025 academic year...', content: 'Detailed welcome message...', tags: ['School News', 'Welcome'], imageUrl: 'https://via.placeholder.com/300x200.png?text=School+Year' },
];

export const mockSuggestions: Suggestion[] = [
    { id: 'sg1', studentId: 'user001', studentName: 'Alex Johnson', subject: 'Library Timings', details: 'Suggesting to extend library hours on weekends.', submittedDate: '2024-09-20', status: 'In Review'},
];

export const mockAppreciations: Appreciation[] = [
    { id: 'ap1', title: 'Science Olympiad Winner', description: 'Secured 1st place in the National Science Olympiad.', awardedBy: 'Mr. Lee', awardedDate: '2024-05-10', category: 'Academic', certificateUrl: '#' },
];

export const mockAcademicRecords: AcademicRecordItem[] = [
    { id: 'ar1', courseName: 'Grade 9 Final Exams', grade: 'A+', completionDate: '2023-03-20' },
    { id: 'ar2', courseName: 'Introduction to Python (Online)', grade: 'Completed', credits: 2, completionDate: '2023-07-15', institution: 'Coursera'},
];

export const mockCoursePlans: CoursePlanSubject[] = [
    {
        subjectName: 'Mathematics - Grade 10',
        items: [
            { id: 'cp_math1', unit: 'Unit 1: Algebra', topic: 'Linear Equations', learningObjectives: ['Solve linear equations', 'Graph linear equations'], durationEstimate: '2 Weeks' },
            { id: 'cp_math2', unit: 'Unit 2: Geometry', topic: 'Triangles', learningObjectives: ['Understand properties of triangles', 'Solve triangle problems'], durationEstimate: '3 Weeks' },
        ]
    },
    {
        subjectName: 'Science - Grade 10',
        items: [
            { id: 'cp_sci1', unit: 'Unit 1: Physics', topic: 'Laws of Motion', learningObjectives: ['Understand Newton\'s Laws', 'Apply laws to solve problems'], durationEstimate: '3 Weeks' },
        ]
    }
];
