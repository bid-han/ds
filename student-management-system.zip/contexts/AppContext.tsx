
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { Theme, UserProfile, NotificationItem, CalendarEvent } from '../types';
import { mockUser, mockNotifications, mockCalendarEvents } from '../services/mockData';

interface AppContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  isLoggedIn: boolean;
  login: (username:string, password: string) => boolean; // Simplified login
  logout: () => void;
  currentUser: UserProfile | null;
  notifications: NotificationItem[];
  markNotificationAsRead: (id: string) => void;
  getUnreadNotificationCount: () => number;
  calendarEvents: CalendarEvent[];
  currentPage: string;
  setCurrentPage: (page: string) => void;
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  setSidebarOpen: (isOpen: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>('light');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>(mockNotifications);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(mockCalendarEvents);
  const [currentPage, setCurrentPage] = useState<string>('dashboard'); // Default page
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);


  useEffect(() => {
    const storedTheme = localStorage.getItem('theme') as Theme | null;
    if (storedTheme) {
      setThemeState(storedTheme);
      document.documentElement.classList.toggle('dark', storedTheme === 'dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setThemeState(prefersDark ? 'dark' : 'light');
      document.documentElement.classList.toggle('dark', prefersDark);
    }
  }, []);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
     // Re-apply theme to ensure documentElement class is correct
    if (newTheme === 'dark') {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
  };

  const login = (username:string, password: string):boolean => {
    // Mock login: accept any username/password for demo, or check against mockUser
    if (username && password) { // In a real app, you'd validate credentials
      setIsLoggedIn(true);
      setCurrentUser(mockUser);
      setCurrentPage('dashboard'); // Navigate to dashboard on login
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setCurrentPage('login'); // Or any other default page after logout
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };
  
  const getUnreadNotificationCount = useCallback(() => {
    return notifications.filter(n => !n.read).length;
  }, [notifications]);

  const toggleSidebar = () => {
    setIsSidebarOpen(prev => !prev);
  };


  return (
    <AppContext.Provider value={{ 
      theme, setTheme, 
      isLoggedIn, login, logout, 
      currentUser, 
      notifications, markNotificationAsRead, getUnreadNotificationCount,
      calendarEvents,
      currentPage, setCurrentPage,
      isSidebarOpen, toggleSidebar, 
      // Fix: Changed setSidebarOpen to setIsSidebarOpen to match the state setter function name.
      setSidebarOpen: setIsSidebarOpen
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};