export type Theme = 'light' | 'dark';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  class: string;
  section: string;
  profilePictureUrl?: string;
  feesDue?: number;
  rollNumber?: string;
  admissionDate?: string; // YYYY-MM-DD
}

export interface NotificationItem {
  id: string;
  type: 'personal' | 'general';
  title: string;
  message: string;
  date: string; // ISO Date string
  read: boolean;
  link?: string;
}

export interface CalendarEvent {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  description: string;
  type: 'event' | 'exam' | 'holiday' | 'assignment';
  calendarType: 'academic' | 'board';
}

export interface MenuItem {
  id: string;
  label: string;
  icon?: React.FC<React.SVGProps<SVGSVGElement>>;
  page: string; // Corresponds to a key in AppContext's PageComponents
  children?: MenuItem[];
}

export interface StudentAccountDetails extends UserProfile {
  totalFees: number;
  paidFees: number;
  balance: number;
  paymentHistory: PaymentRecord[];
}

export interface PaymentRecord {
  id: string;
  date: string; // YYYY-MM-DD
  amount: number;
  method: string;
  transactionId: string;
}

export interface Assignment {
  id: string;
  subject: string;
  title: string;
  description: string;
  assignedDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  status: 'Pending' | 'Submitted' | 'Graded';
  grade?: string; // e.g., "A+", "85/100"
  fileUrl?: string; // Link to submitted file or assignment details
}

export interface AttendanceRecord {
  month: string; // e.g., "October 2024"
  totalDays: number;
  presentDays: number;
  absentDays: number;
  percentage: number;
  dailyRecords?: { date: string; status: 'Present' | 'Absent' | 'Leave' }[];
}

export interface ReportCardSubject {
  name: string;
  marksObtained: number;
  totalMarks: number;
  grade: string;
  remarks?: string;
}
export interface ReportCardSummary {
  id: string;
  term: string; // e.g., "Mid-Term 2024", "Final Term 2023"
  issueDate: string; // YYYY-MM-DD
  overallPercentage: number;
  overallGrade: string;
  subjects: ReportCardSubject[];
  downloadUrl?: string;
  teacherComments?: string;
  principalComments?: string;
}

export interface TimetableEntry {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  time: string; // e.g., "09:00 AM - 10:00 AM"
  subject: string;
  teacher: string;
  room?: string;
}

export interface LeaveNote {
  id: string;
  studentId: string;
  studentName: string;
  fromDate: string; // YYYY-MM-DD
  toDate: string; // YYYY-MM-DD
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  submittedDate: string; // YYYY-MM-DD
  attachmentUrl?: string; // Optional medical certificate etc.
}

export interface StudentDocument {
  id: string;
  name: string;
  type: 'Certificate' | 'ID Card' | 'Report' | 'Other';
  uploadDate: string; // YYYY-MM-DD
  fileUrl: string; // Link to view/download
  size?: string; // e.g., "2.5MB"
}

// Further types for other sections can be added below
export interface ReadingMaterial {
  id: string;
  title: string;
  subject: string;
  type: 'PDF' | 'Notes' | 'Link';
  url: string;
  addedDate: string;
}

export interface MediaItem {
  id: string;
  title: string;
  type: 'image' | 'video';
  url: string;
  thumbnailUrl?: string;
  eventDate?: string;
  description?: string;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  isbn: string;
  genre: string;
  availableCopies: number;
  totalCopies: number;
  coverImageUrl?: string;
}

export interface DownloadableFile {
  id: string;
  name: string;
  category: 'Form' | 'Syllabus' | 'Document';
  url: string;
  size: string;
  uploadDate: string;
}

export interface EducationalVideo {
  id: string;
  title: string;
  subject: string;
  description: string;
  url: string; // YouTube or other video link
  thumbnailUrl?: string;
  duration: string; // e.g., "10:32"
  uploadedBy: string; // Teacher name or School
}

export interface BlogPost {
  id: string;
  title: string;
  author: string;
  publishDate: string;
  excerpt: string;
  content: string; // Can be markdown or HTML
  tags?: string[];
  imageUrl?: string;
}

export interface Suggestion {
    id: string;
    studentId: string;
    studentName: string;
    subject: string;
    details: string;
    submittedDate: string;
    status: 'Received' | 'In Review' | 'Implemented' | 'Declined';
}

export interface Appreciation {
    id: string;
    title: string;
    description: string;
    awardedBy: string; // Teacher Name
    awardedDate: string;
    category: 'Academic' | 'Sports' | 'Arts' | 'Conduct';
    certificateUrl?: string;
}

export interface AcademicRecordItem {
    id: string;
    courseName: string;
    grade: string;
    credits?: number;
    completionDate: string;
    institution?: string; // If for external courses
}

export interface CoursePlanItem {
    id: string;
    unit: string; // e.g., "Unit 1: Algebra Basics"
    topic: string;
    learningObjectives: string[];
    resources?: { name: string, url: string }[];
    durationEstimate: string; // e.g., "2 weeks"
}

export interface CoursePlanSubject {
    subjectName: string;
    items: CoursePlanItem[];
}
